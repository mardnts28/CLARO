import { Link } from 'react-router-dom';
import logoImg from '../assets/images/logoII.png';
import './Footer.css';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          {/* Brand Info Column */}
          <div className="footer-brand">
            <img src={logoImg} alt="CLARO Logo" className="footer-logo" />
            <p className="footer-description">
              Smart food recognition and nutrition guidance capstone project platform designed to empower healthier food choices.
            </p>
            <div className="footer-socials">
              <a
                href="https://github.com/mardnts28/CLARO/tree/main"
                className="social-icon-btn"
                title="CLARO GitHub Repository"
                aria-label="CLARO GitHub Repository"
                target="_blank"
                rel="noopener noreferrer"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/>
                  <path d="M9 18c-4.51 2-5-2-7-2"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Quick Links Column */}
          <div>
            <h4 className="footer-heading">Quick Links</h4>
            <ul className="footer-links">
              <li>
                <Link to="/" className="footer-link">Home</Link>
              </li>
              <li>
                <Link to="/user-guide" className="footer-link">User Guide</Link>
              </li>
              <li>
                <Link to="/about-developers" className="footer-link">About the Developers</Link>
              </li>
            </ul>
          </div>

          {/* Legal Links Column */}
          <div>
            <h4 className="footer-heading">Legal & Info</h4>
            <ul className="footer-links">
              <li>
                <Link to="/privacy-policy" className="footer-link">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/terms-and-conditions" className="footer-link">Terms & Conditions</Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Footer Bottom Bar */}
        <div className="footer-bottom">
          <p>© {currentYear} CLARO Capstone Project. All rights reserved.</p>
          <div className="footer-bottom-links">
            <Link to="/privacy-policy" className="footer-link">Privacy</Link>
            <Link to="/terms-and-conditions" className="footer-link">Terms</Link>
            <a href="http://localhost:5174/login" className="footer-link" target="_blank" rel="noopener noreferrer">Admin</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
