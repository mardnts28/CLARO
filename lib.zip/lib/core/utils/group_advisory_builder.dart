// lib/core/utils/group_advisory_builder.dart
//
// Everything needed to turn N members' product evaluations into ONE group
// verdict: the per-member facts, the Gemini prompt, the response name
// restoration, and the rule-based fallback used when Gemini is unavailable,
// not needed (everyone suitable), or the pack size was changed on screen.
//
// PRIVACY: the prompt never contains member names. Each member is sent as
// an opaque tag ([M1], [M2] ...; the signed-in user is [YOU]) and the tags
// are swapped back to display names locally after Gemini answers. Health
// conditions are therefore never sent to Gemini alongside a person's name.

import '../../data/models/group_evaluation.dart';
import '../../data/models/health_advisory.dart';
import '../../data/models/health_profile.dart';
import '../../data/models/product_evaluation.dart';
import '../../models/product_model.dart'; // nutritionPer100g extension
import '../constants/who_fda_thresholds.dart';
import 'serving_size_calculator.dart';
import 'who_calculator.dart';

/// Formats percentage wording for health advisories.
/// If percentage <= 100%, returns "X% of the Recommended Daily Intake"
/// If percentage > 100%, returns "(X-100)% above the Recommended Daily Intake"
String _formatPercentageWording(double percentage, bool isTagalog) {
  if (percentage <= 100) {
    return isTagalog
        ? '${percentage.toStringAsFixed(1)}% ng Recommended Daily Intake'
        : '${percentage.toStringAsFixed(1)}% of the Recommended Daily Intake';
  } else {
    final above = percentage - 100;
    return isTagalog
        ? '${above.toStringAsFixed(1)}% sa taas ng Recommended Daily Intake'
        : '${above.toStringAsFixed(1)}% above the Recommended Daily Intake';
  }
}

class GroupMemberFacts {
  final String alias; // '[M1]' ... or '[YOU]' -- what Gemini sees
  final String name; // display name -- NEVER sent to Gemini
  final bool isSelf;
  final AdvisoryLevel level;
  final List<String> conditions; // english names
  final List<String>
  allergens; // e.g. 'Dairy/Milk (ingredient "Whey", derived)'
  final String? nutrientKey; // main nutrient of concern, null if none
  final double? amountPerServing;
  final double? percentOfDaily;
  // App-calculated suggested grams PER MEAL (ServingSizeCalculator), for
  // Suitable, Moderate and Caution members alike: the most restrictive
  // nutrient tied to the member's conditions, or -- for a member with no
  // conditions -- the combined sodium/sugars/saturated-fat amount, exactly
  // like the single-user advisory. Null when an allergen match is present
  // (a smaller portion doesn't make an allergen match acceptable) or the
  // product has none of the relevant nutrients.
  final double? suggestedGrams;

  const GroupMemberFacts({
    required this.alias,
    required this.name,
    required this.isSelf,
    required this.level,
    required this.conditions,
    required this.allergens,
    this.nutrientKey,
    this.amountPerServing,
    this.percentOfDaily,
    this.suggestedGrams,
  });

  bool get isFlagged => level != AdvisoryLevel.suitable;
}

class GroupAdvisoryBuilder {
  GroupAdvisoryBuilder._();

  // ── Levels ──────────────────────────────────────────────────────────

  /// A member's verdict for [servingSizeG]. Same rules as the single-user
  /// screen: an allergen match is always Caution; otherwise the worst
  /// nutrient level recomputed for the chosen size.
  static AdvisoryLevel levelAt(ProductEvaluation ev, double servingSizeG) {
    if (ev.allergenAssessment.hasDirectAllergen) return AdvisoryLevel.caution;

    var worst = ev.scoredFactors.fold<AdvisoryLevel>(
      AdvisoryLevel.suitable,
      (current, factor) => _worseLevel(current, factor.level),
    );
    for (final n in ev.nutrientEvaluations) {
      final level = _nutrientLevelAt(n, servingSizeG);
      worst = _worseLevel(worst, level);
    }
    return worst;
  }

  static AdvisoryLevel _worseLevel(AdvisoryLevel first, AdvisoryLevel second) {
    if (first == AdvisoryLevel.caution || second == AdvisoryLevel.caution) {
      return AdvisoryLevel.caution;
    }
    if (first == AdvisoryLevel.moderate || second == AdvisoryLevel.moderate) {
      return AdvisoryLevel.moderate;
    }
    return AdvisoryLevel.suitable;
  }

  static AdvisoryLevel groupLevel(Iterable<AdvisoryLevel> levels) {
    var worst = AdvisoryLevel.suitable;
    for (final l in levels) {
      if (l == AdvisoryLevel.caution) return AdvisoryLevel.caution;
      if (l == AdvisoryLevel.moderate) worst = AdvisoryLevel.moderate;
    }
    return worst;
  }

  static int severity(AdvisoryLevel l) => switch (l) {
    AdvisoryLevel.suitable => 0,
    AdvisoryLevel.moderate => 1,
    AdvisoryLevel.caution => 2,
  };

  static double _percentAt(NutrientEvaluation n, double servingSizeG) {
    final value = (n.valuePer100g / 100) * servingSizeG;
    return (value / WhoCalculator.getWhoDailyLimit(n.nutrientKey)) * 100;
  }

  static AdvisoryLevel _nutrientLevelAt(
    NutrientEvaluation n,
    double servingSizeG,
  ) => WhoCalculator.classifyByWhoPercentage(_percentAt(n, servingSizeG));

  // ── Facts ───────────────────────────────────────────────────────────

  /// Facts for every member, in the order given, at [servingSizeG].
  static List<GroupMemberFacts> buildFacts(
    List<MemberEvaluation> members,
    double servingSizeG,
  ) {
    var n = 0;
    return members.map((m) {
      final alias = m.isSelf ? '[YOU]' : '[M${++n}]';
      return _factsFor(m, alias, servingSizeG);
    }).toList();
  }

  /// Facts for a single member (alias unused) -- for UI that needs one
  /// member's suggested amount without building the whole group.
  static GroupMemberFacts memberFacts(
    MemberEvaluation m,
    double servingSizeG,
  ) => _factsFor(m, '', servingSizeG);

  static GroupMemberFacts _factsFor(
    MemberEvaluation m,
    String alias,
    double size,
  ) {
    final ev = m.evaluation;
    final level = levelAt(ev, size);

    // Nutrient of concern: highest severity, then highest % of daily limit.
    NutrientEvaluation? worst;
    var worstSeverity = 0;
    var worstPct = -1.0;
    for (final ne in ev.nutrientEvaluations) {
      final pct = _percentAt(ne, size);
      final sev = severity(WhoCalculator.classifyByWhoPercentage(pct));
      if (sev == 0) continue;
      if (sev > worstSeverity || (sev == worstSeverity && pct > worstPct)) {
        worst = ne;
        worstSeverity = sev;
        worstPct = pct;
      }
    }

    final allergens = <String>[];
    for (final src in ev.allergenAssessment.ingredientSources) {
      final how = src.matchType == AllergenMatchType.direct
          ? 'direct'
          : 'derived';
      allergens.add(
        src.ingredient == null
            ? src.allergen.displayLabel
            : '${src.allergen.displayLabel} (ingredient "${src.ingredient}", $how)',
      );
    }
    if (allergens.isEmpty) {
      allergens.addAll(
        ev.allergenAssessment.matchedContains.map((a) => a.displayLabel),
      );
    }

    return GroupMemberFacts(
      alias: alias,
      name: m.name,
      isSelf: m.isSelf,
      level: level,
      conditions: m.profile.conditions.map(_conditionName).toList(),
      allergens: allergens,
      nutrientKey: worst?.nutrientKey,
      amountPerServing: worst == null
          ? null
          : (worst.valuePer100g / 100) * size,
      percentOfDaily: worst == null ? null : worstPct,
      suggestedGrams: allergens.isNotEmpty ? null : _suggestedGramsFor(m, size),
    );
  }

  // ── Suggested amounts ───────────────────────────────────────────────

  static double? _suggestedGramsFor(MemberEvaluation m, double size) {
    final ev = m.evaluation;
    if (m.profile.conditions.isEmpty || ev.nutrientEvaluations.isEmpty) {
      return ServingSizeCalculator.suggestedGramsCombined(
        nutritionPer100g: ev.product.nutritionPer100g,
        servingSizeG: size,
      );
    }
    double? smallest;
    for (final n in ev.nutrientEvaluations) {
      final g = ServingSizeCalculator.suggestedGrams(
        nutrientKey: n.nutrientKey,
        valuePer100g: n.valuePer100g,
        servingSizeG: size,
      );
      if (g != null && (smallest == null || g < smallest)) smallest = g;
    }
    return smallest;
  }

  /// "up to 1 full serving (50g)" / "about half a serving (25g)" /
  /// "no more than 20g" -- same three bands ServingSizeCalculator uses for
  /// the single-user advisory.
  static String amountPhrase(
    double grams,
    double servingSizeG, {
    bool tl = false,
  }) {
    final ratio = servingSizeG <= 0 ? 1.0 : grams / servingSizeG;
    final g = grams < 1 ? '<1g' : '${grams.round()}g';
    if (ratio >= 1.0) {
      return tl
          ? 'hanggang 1 buong serving (${servingSizeG.round()}g)'
          : 'up to 1 full serving (${servingSizeG.round()}g)';
    }
    if (ratio >= 0.5) {
      return tl ? 'mga kalahating serving ($g)' : 'about half a serving ($g)';
    }
    return tl ? 'hindi hihigit sa $g' : 'no more than $g';
  }

  /// One member's suggested amount at any level, or null when none applies
  /// (allergen match, or the product has none of the relevant nutrients).
  static String? memberAmountLine(
    GroupMemberFacts f,
    double servingSizeG, {
    bool tl = false,
  }) {
    if (f.suggestedGrams == null) return null;
    final phrase = amountPhrase(f.suggestedGrams!, servingSizeG, tl: tl);
    return tl
        ? 'Iminumungkahi bawat kain: $phrase, para sa 3 kain sa isang araw'
        : 'Suggested per meal: $phrase, for 3 meals a day';
  }

  /// The single amount that fits everyone in the group: the SMALLEST of
  /// their suggested amounts (same strictest-member rule as the group
  /// verdict). Null when nobody has one. [token] is the grams
  /// figure as it appears in [sentence], used to check that Gemini kept it.
  static ({String sentence, String token})? groupAmount(
    List<GroupMemberFacts> facts,
    double servingSizeG, {
    bool tl = false,
  }) {
    double? smallest;
    for (final f in facts) {
      if (f.suggestedGrams == null) continue;
      if (smallest == null || f.suggestedGrams! < smallest) {
        smallest = f.suggestedGrams;
      }
    }
    if (smallest == null) return null;

    final phrase = amountPhrase(smallest, servingSizeG, tl: tl);
    final sentence = tl
        ? 'Para sa buong grupo: $phrase bawat kain, para sa 3 kain sa isang araw.'
        : 'To fit everyone in the group: $phrase per meal, for 3 meals a day.';
    final ratio = servingSizeG <= 0 ? 1.0 : smallest / servingSizeG;
    final token = ratio >= 1.0
        ? '${servingSizeG.round()}g'
        : (smallest < 1 ? '<1g' : '${smallest.round()}g');
    return (sentence: sentence, token: token);
  }

  // ── Gemini prompt ───────────────────────────────────────────────────

  static String buildPrompt({
    required String productName,
    required double servingSizeG,
    required List<GroupMemberFacts> facts,
    String languageCode = 'en',
  }) {
    final level = groupLevel(facts.map((f) => f.level));
    final flagged = facts.where((f) => f.isFlagged).length;

    final memberLines = facts
        .map((f) {
          final b = StringBuffer(
            '${f.alias}${f.isSelf ? " (the person using the app)" : ""} - Level: ${_levelLabel(f.level)}.',
          );
          b.write(
            ' Health conditions: ${f.conditions.isEmpty ? "none" : f.conditions.join(", ")}.',
          );
          if (f.allergens.isNotEmpty) {
            b.write(
              ' Contains an allergen this member is allergic to: ${f.allergens.join("; ")}.',
            );
          }
          if (f.nutrientKey != null) {
            b.write(
              ' Main nutrient of concern: ${_nutrientLabel(f.nutrientKey!)}, '
              '${f.amountPerServing!.toStringAsFixed(1)}${_nutrientUnit(f.nutrientKey!)} per serving '
              '(${_formatPercentageWording(f.percentOfDaily!, false)}).',
            );
          }
          return '- ${b.toString()}';
        })
        .join('\n');

    final language = languageCode == 'tl'
        ? 'Respond in simple, conversational Tagalog.'
        : 'Respond in simple, conversational English.';

    final amount = groupAmount(facts, servingSizeG, tl: languageCode == 'tl');
    final amountFacts = amount == null
        ? ''
        : '\nSuggested amount for the group (already calculated by the application): "${amount.sentence}"\n';
    final amountRule = amount == null
        ? '- Do not mention any serving amount; none was supplied.'
        : '- After your sentences, end the explanation with the suggested-amount sentence above, copied EXACTLY as written. Do not change, convert, or restate any number in it, and do not mention any other serving amount.';

    return '''
You are a wording assistant for the Group Health Advisory card in a Filipino grocery app called CLARO. Several people share one health group. Write ONE short advisory about the scanned product for the whole group, using ONLY the facts below.

Product: $productName
Serving size: ${servingSizeG.toStringAsFixed(0)}g
Overall group level: ${_levelLabel(level)} ($flagged of ${facts.length} members flagged).

Members:
$memberLines
$amountFacts
$language

IMPORTANT:
- Refer to each member ONLY by the exact tag shown (for example [M1]), copied character for character. Never invent, guess, or write a real name.
- [YOU] is the person using the app: address them as "you" and do not write the tag itself.
- The application already calculated every amount, percentage and level. You must NOT calculate, derive, estimate, or invent any number. Use only the numbers supplied above.
- Never describe anything as "safe" or medically recommended. Use non-medical, non-diagnostic, cautious language.
- Do not say the product causes, worsens, or triggers any condition, and do not tell anyone what they must do or avoid. Allergen warnings are the exception: cautious wording such as "may cause an allergic reaction" or "consume with caution or avoid" is fine for members flagged for an allergen.
- Do not mention calculations, algorithms, or risk scores.

WARNINGTEXT field:
- Maximum 8 words.
- Do NOT repeat the level words ("Caution", "Moderate", "Suitable") -- the UI shows them separately.
- Example: "High sodium for some members".

EXPLANATION field -- at most 2 short sentences, about 30-45 words in total:
- Sentence 1: say who is flagged (by tag) and the main reason for each, using only the supplied nutrient or allergen facts.
- Sentence 2 (only if some members are not flagged): one short line saying the others are not flagged. If everyone is flagged, write only sentence 1. Do not give advice and do not invent serving amounts.
- If nobody is flagged, write one short sentence saying the product looks suitable for the whole group.
$amountRule

Return ONLY valid JSON, no markdown, matching exactly this shape:
{
  "warningText": "short headline, max 8 words",
  "explanation": "the advisory text following the instructions above"
}
''';
  }

  /// Swaps the privacy tags back to display names. Returns null if any tag
  /// (or a tag-like leftover such as "M2") survives, so the caller can fall
  /// back to the deterministic text instead of showing a broken sentence.
  static String? restoreNames(
    String text,
    List<GroupMemberFacts> facts,
    String languageCode,
  ) {
    var out = text;
    for (final f in facts) {
      if (f.isSelf) continue;
      out = out.replaceAll(f.alias, f.name);
    }
    out = out.replaceAll('[YOU]', languageCode == 'tl' ? 'ikaw' : 'you');
    if (RegExp(r'\[?\bM\d+\b\]?').hasMatch(out)) return null;
    return out;
  }

  // ── Fallback (no Gemini) ────────────────────────────────────────────

  static HealthAdvisory fallback(
    List<GroupMemberFacts> facts, {
    required double servingSizeG,
    String languageCode = 'en',
  }) {
    final tl = languageCode == 'tl';
    final level = groupLevel(facts.map((f) => f.level));
    final flagged = facts.where((f) => f.isFlagged).toList()
      ..sort((a, b) => severity(b.level).compareTo(severity(a.level)));

    if (flagged.isEmpty) {
      final suitableAmount = groupAmount(facts, servingSizeG, tl: tl);
      final base = tl
          ? 'Mukhang angkop ang produktong ito para sa lahat ng miyembro ng grupo.'
          : 'This product looks suitable for everyone in the group.';
      return _advisory(
        level,
        tl ? 'Angkop para sa buong grupo' : 'Suitable for the whole group',
        suitableAmount == null ? base : '$base ${suitableAmount.sentence}',
        safeServingSize: suitableAmount?.sentence,
      );
    }

    final parts = flagged
        .map((f) {
          final who = f.isSelf ? (tl ? 'Ikaw' : 'You') : f.name;
          final String why;
          if (f.allergens.isNotEmpty) {
            why = tl
                ? 'may allergen (${f.allergens.map(_stripDetail).join(", ")})'
                : 'contains an allergen (${f.allergens.map(_stripDetail).join(", ")})';
          } else if (f.nutrientKey != null) {
            why = tl
                ? '${_nutrientLabelTl(f.nutrientKey!)} - ${_formatPercentageWording(f.percentOfDaily!, true)}'
                : '${_nutrientLabel(f.nutrientKey!)} - ${_formatPercentageWording(f.percentOfDaily!, false)}';
          } else {
            why = tl ? 'kailangang bantayan' : 'worth watching';
          }
          return '$who ($why)';
        })
        .join('; ');

    final others = facts.length - flagged.length;
    final tail = others > 0
        ? (tl
              ? ' Hindi naman naka-flag ang iba pa.'
              : ' The others are not flagged.')
        : '';
    final head = level == AdvisoryLevel.caution
        ? (tl ? 'Mag-ingat: ' : 'Be careful: ')
        : (tl ? 'Bantayan: ' : 'Keep an eye on: ');

    final amount = groupAmount(facts, servingSizeG, tl: tl);

    return _advisory(
      level,
      level == AdvisoryLevel.caution
          ? (tl
                ? 'May dapat mag-ingat sa grupo'
                : 'Some members need to be careful')
          : (tl
                ? 'May dapat magbantay sa grupo'
                : 'Some members should watch this'),
      '$head$parts.$tail${amount == null ? '' : ' ${amount.sentence}'}',
      safeServingSize: amount?.sentence,
    );
  }

  static HealthAdvisory _advisory(
    AdvisoryLevel level,
    String title,
    String text, {
    String? safeServingSize,
  }) => HealthAdvisory(
    overallLevel: level,
    warningText: title,
    explanation: text,
    safeServingSize: safeServingSize,
    source: AdvisorySource.fallbackRuleBased,
    generatedAt: DateTime.now(),
  );

  static String _stripDetail(String allergen) {
    final i = allergen.indexOf(' (');
    return i == -1 ? allergen : allergen.substring(0, i);
  }

  // ── Cache fingerprint ───────────────────────────────────────────────

  /// Stable across runs (unlike String.hashCode), changes whenever the
  /// product, serving size, member names, levels, conditions, or allergens
  /// change -- so a cached group advisory can never describe an old group.
  static String fingerprint(
    String productId,
    double servingSizeG,
    List<GroupMemberFacts> facts,
  ) {
    final b = StringBuffer('$productId|${servingSizeG.toStringAsFixed(1)}');
    final sorted = [...facts]..sort((x, y) => x.name.compareTo(y.name));
    for (final f in sorted) {
      b.write(
        '|${f.name}:${f.level.name}:${f.conditions.join(",")}:${f.allergens.join(",")}'
        ':${f.nutrientKey}:${f.percentOfDaily?.toStringAsFixed(0)}:${f.suggestedGrams?.toStringAsFixed(0)}',
      );
    }
    var h = 0x811c9dc5;
    for (final c in b.toString().codeUnits) {
      h ^= c;
      h = (h * 0x01000193) & 0xFFFFFFFF;
    }
    return h.toRadixString(16);
  }

  // ── Labels ──────────────────────────────────────────────────────────

  static String _levelLabel(AdvisoryLevel l) => switch (l) {
    AdvisoryLevel.suitable => 'Suitable',
    AdvisoryLevel.moderate => 'Moderate',
    AdvisoryLevel.caution => 'Caution',
  };

  static String _conditionName(HealthCondition c) => switch (c) {
    HealthCondition.hypertension => 'hypertension',
    HealthCondition.diabetes => 'diabetes',
    HealthCondition.heartCondition => 'heart condition',
    HealthCondition.gerd => 'GERD',
    HealthCondition.kidneyDisease => 'kidney disease',
  };

  static String _nutrientLabel(String key) => switch (key) {
    'sodiumMg' => 'sodium',
    'sugarsG' => 'total sugars',
    'saturatedFatG' => 'saturated fat',
    _ => key,
  };

  static String _nutrientLabelTl(String key) => switch (key) {
    'sodiumMg' => 'sodium',
    'sugarsG' => 'kabuuang asukal',
    'saturatedFatG' => 'saturated fat',
    _ => key,
  };

  static String _nutrientUnit(String key) => key == 'sodiumMg' ? 'mg' : 'g';
}