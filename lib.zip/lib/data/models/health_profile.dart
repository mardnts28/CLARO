// lib/data/models/health_profile.dart
//
// Represents a user's health profile as it will eventually be stored in
// Firestore under: users/{userId}/healthProfile

enum HealthCondition {
  hypertension,
  diabetes,
  heartCondition,
  // Conditions with deterministic scoring factors. They may also drive
  // informational warning cards. New values are
  // appended at the end and (de)serialized by name, so existing saved
  // profiles keep loading exactly as before.
  gerd,
  kidneyDisease,
}

extension HealthConditionKind on HealthCondition {
  /// True for conditions that participate in deterministic scoring/ranking.
  bool get isScored {
    switch (this) {
      case HealthCondition.hypertension:
      case HealthCondition.diabetes:
      case HealthCondition.heartCondition:
      case HealthCondition.gerd:
      case HealthCondition.kidneyDisease:
        return true;
    }
  }

  bool get isAwarenessOnly => !isScored;
}

// Common allergens relevant to Filipino canned food & instant noodles.
// Extend this list as your dataset coverage grows.
enum AllergenType {
  shellfish,
  fish,
  peanuts,
  treeNuts,
  soy,
  dairy,
  eggs,
  wheatGluten,
  msg, // not a true allergen, but frequently flagged as a sensitivity
}

// Human-readable labels for AllergenType, for UI display (e.g. warning
// banners). Kept alongside the enum so any screen can reuse it instead of
// re-deriving its own copy.
extension AllergenTypeDisplay on AllergenType {
  String get displayLabel {
    switch (this) {
      case AllergenType.shellfish:
        return 'Shellfish';
      case AllergenType.fish:
        return 'Fish';
      case AllergenType.peanuts:
        return 'Peanuts';
      case AllergenType.treeNuts:
        return 'Tree Nuts';
      case AllergenType.soy:
        return 'Soy';
      case AllergenType.dairy:
        return 'Dairy/Milk';
      case AllergenType.eggs:
        return 'Eggs';
      case AllergenType.wheatGluten:
        return 'Wheat/Gluten';
      case AllergenType.msg:
        return 'MSG';
    }
  }
}

class UserHealthProfile {
  final String userId;
  final String displayName;
  final List<HealthCondition> conditions;
  final List<AllergenType> allergies;
  // Hands-free voice navigation toggle. The feature itself belongs to a
  // teammate's module, but the on/off state lives on the user doc, so it's
  // represented here.
  final bool voiceAssistant;

  const UserHealthProfile({
    required this.userId,
    required this.displayName,
    required this.conditions,
    required this.allergies,
    this.voiceAssistant = false,
  });

  bool get hasHypertension => conditions.contains(HealthCondition.hypertension);
  bool get hasDiabetes => conditions.contains(HealthCondition.diabetes);
  bool get hasHeartCondition =>
      conditions.contains(HealthCondition.heartCondition);
  bool get hasGerd => conditions.contains(HealthCondition.gerd);
  bool get hasKidneyDisease =>
      conditions.contains(HealthCondition.kidneyDisease);

  /// Conditions that feed the existing Suitable/Moderate/Caution scoring.
  List<HealthCondition> get scoredConditions =>
      conditions.where((c) => c.isScored).toList();
  bool get hasAnyAllergy => allergies.isNotEmpty;

  /// Unique deterministic fingerprint representing the user's current health state.
  /// Any change in conditions or allergies alters this string, automatically
  /// invalidating cached AI advisories that depended on the previous state.
  String get profileFingerprint {
    final sortedConditions = conditions.map((c) => c.name).toList()..sort();
    final sortedAllergies = allergies.map((a) => a.name).toList()..sort();
    return '${userId}_c[${sortedConditions.join(",")}]_a[${sortedAllergies.join(",")}]';
  }

  factory UserHealthProfile.fromJson(Map<String, dynamic> json) {
    return UserHealthProfile(
      userId: json['userId']?.toString() ?? '',
      displayName: json['displayName']?.toString() ?? '',
      conditions: (json['conditions'] as List<dynamic>? ?? [])
          .map(
            (c) => HealthCondition.values.cast<HealthCondition?>().firstWhere(
              (e) => e?.name == c?.toString(),
              orElse: () => null,
            ),
          )
          .whereType<HealthCondition>()
          .toList(),
      allergies: (json['allergies'] as List<dynamic>? ?? [])
          .map(
            (a) => AllergenType.values.cast<AllergenType?>().firstWhere(
              (e) => e?.name == a?.toString(),
              orElse: () => null,
            ),
          )
          .whereType<AllergenType>()
          .toList(),
      voiceAssistant: json['voiceAssistant'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
    'userId': userId,
    'displayName': displayName,
    'conditions': conditions.map((c) => c.name).toList(),
    'allergies': allergies.map((a) => a.name).toList(),
    'voiceAssistant': voiceAssistant,
  };
}
