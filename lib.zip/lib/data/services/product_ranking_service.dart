// lib/data/services/product_ranking_service.dart
//
// rankProducts(): FREE. Pure Dart, zero Gemini calls -- powers the
// "multiple product compared interface" list (names + rank only).
//
// getProductDetail(): the ONLY method here that touches Gemini, and only
// for ONE product, only when the user actually taps into it. Powers the
// "solo product interface" screen -- returns the health advisory AND the
// red/green/neutral nutrient comparison table together, since both are
// shown on that same screen. The comparison table itself is free (pure
// Dart); only the advisory/explanation text costs a Gemini call.

import 'gemini_advisory_service.dart';
import '../models/health_profile.dart';
import '../../models/product_model.dart';
import '../models/product_detail_result.dart';
import '../models/ranked_product_result.dart';
import '../../core/utils/who_calculator.dart';
import '../../core/utils/comparison_calculator.dart';
import '../../core/utils/comparison_matrix_builder.dart';
import '../../core/constants/who_fda_thresholds.dart';

// Module says "up to 3-5 products" per scan/comparison event.
const int kMaxProductsPerRanking = 5;

class ProductRankingService {
  ProductRankingService({required GeminiAdvisoryService geminiService})
      : _geminiService = geminiService;

  final GeminiAdvisoryService _geminiService;

  /// Ranks [products] against [user]'s profile. Pure Dart -- no API calls,
  /// safe to call as often as needed (rebuilds, re-sorts, etc.) at zero cost.
  /// Powers the ranked list-of-names screen.
  ///
  /// [enforceMaxCap] gates the $kMaxProductsPerRanking-item hard limit.
  /// Defaults to true, which is what Scenario A (multi-product scan --
  /// MultiScanResultsScreen, always fed at most 5 detections -- see
  /// CameraScannerScreen's `.take(5)`) and the solo-product path
  /// (ProductDetailScreen, always a 1-item list) rely on. Scenario B (the
  /// "Compare" button -- ProductComparisonService.compareWithAlternatives
  /// and CompareProductsScreen's re-rank-on-filter-change) passes
  /// `enforceMaxCap: false`, since it intentionally ranks every
  /// same-category product regardless of count; the UI layer, not this
  /// method, is responsible for paginating that longer list behind
  /// "See More".
  List<RankedProductResult> rankProducts({
    required List<Product> products,
    required UserHealthProfile user,
    bool enforceMaxCap = true,
  }) {
    if (enforceMaxCap && products.length > kMaxProductsPerRanking) {
      throw ArgumentError(
        'CLARO supports ranking up to $kMaxProductsPerRanking products per '
        'scan event, got ${products.length}.',
      );
    }
    if (products.isEmpty) return [];

    final ranked = WhoCalculator.rankProducts(products, user);
    final labels = computeSuitabilityRankLabels(ranked);

    return List.generate(
      ranked.length,
      (i) => RankedProductResult(
        rank: i + 1,
        evaluation: ranked[i],
        suitabilityRankLabel: labels[i],
      ),
    );
  }

  /// Called when the user taps a specific product to view its detail
  /// screen. Returns BOTH the health advisory (ONE Gemini call, includes
  /// comparisonExplanation if [comparisonSet] has 2+ entries) AND the
  /// nutrient comparison matrix (free, pure Dart -- always built when
  /// [comparisonSet] has 2+ entries, regardless of whether the advisory
  /// call succeeds or falls back).
  ///
  /// If [comparisonSet] is null or has just [target] (solo scan, Scenario
  /// A before Compare is tapped), this returns advisory-only, with
  /// comparisonMatrix left null -- matches the original Phase 2 solo flow.
  Future<ProductDetailResult> getProductDetail({
    required RankedProductResult target,
    List<RankedProductResult>? comparisonSet,
    required UserHealthProfile user,
    required String scanEventId,
    String languageCode = 'en',
  }) async {
    final isComparing = comparisonSet != null && comparisonSet.length > 1;

    ComparisonFact? primaryFact;
    if (isComparing) {
      final facts = ComparisonCalculator.computeFacts(
        target: target.evaluation,
        comparisonSet: comparisonSet.map((r) => r.evaluation).toList(),
        user: user,
      );
      primaryFact = ComparisonCalculator.primaryFact(facts);
    }

    final advisory = await _geminiService.generateAdvisory(
      scanEventId: scanEventId,
      evaluation: target.evaluation,
      user: user,
      comparisonFact: primaryFact,
      rankLabel: primaryFact != null ? target.suitabilityRankLabel : null,
      languageCode: languageCode,
    );

    // Free -- pure Dart, no network. Built whenever there's actually
    // something to compare against; null otherwise (solo scan).
    final comparisonMatrix = isComparing
        ? ComparisonMatrixBuilder.build(
            comparisonSet: comparisonSet.map((r) => r.evaluation).toList(),
            user: user,
          )
        : null;

    // Generate ranking explanation if comparing
    String? rankingExplanation;
    if (isComparing) {
      rankingExplanation = await _generateRankingExplanation(
        target: target,
        comparisonSet: comparisonSet,
        user: user,
        languageCode: languageCode,
      );
    }

    return ProductDetailResult(
      advisory: advisory,
      comparisonMatrix: comparisonMatrix,
      rankingExplanation: rankingExplanation,
    );
  }

  Future<String> _generateRankingExplanation({
    required RankedProductResult target,
    required List<RankedProductResult> comparisonSet,
    required UserHealthProfile user,
    required String languageCode,
  }) async {
    // Health condition name is attached to every branch below so the
    // explanation always ties back to *why* the nutrient matters to this
    // user, not just the raw numbers/rank.
    final conditionName = _getConditionName(user);
    final conditionSuffix =
        conditionName.isNotEmpty ? ' for your $conditionName' : '';
    final totalProducts = comparisonSet.length;

    // Allergen override is a HARD rule in WhoCalculator.rankProducts --
    // any product matching an allergy on the user's profile is forced to
    // last place no matter how good its nutrients look. The explanation
    // must lead with that same hard rule, or a product can end up ranked
    // last for an allergy reason while its explanation talks about
    // nutrients as if it were a close, nutrient-driven call. Deterministic
    // and skips Gemini entirely, same as the "suitable" shortcut below --
    // this is a fact from the profile, not something that benefits from
    // AI phrasing variance.
    if (target.evaluation.allergenOverride) {
      final allergens = target.evaluation.allergenAssessment.matchedContains
          .map(_allergenLabel)
          .join(', ');
      return 'This product ranks ${target.rank} of $totalProducts because it '
          'contains $allergens, which matches an allergy on your profile. '
          'We recommend avoiding it regardless of its other nutrients.';
    }

    // Skip Gemini if product is suitable - use default explanation
    if (target.evaluation.overallLevel == AdvisoryLevel.suitable) {
      return 'This product ranks ${target.rank} of $totalProducts and is suitable for your health profile${conditionName.isNotEmpty ? " ($conditionName)" : ""}.';
    }

    // Get the nutrient that best explains THIS product's position, across
    // ALL of the user's conditions -- not just the first one -- so a user
    // with e.g. hypertension + heart condition doesn't lose the
    // saturated-fat story just because sodium happens to be listed first.
    final fact = _primaryComparisonFact(
      target: target,
      comparisonSet: comparisonSet,
      user: user,
    );
    if (fact == null) {
      return 'This product ranks ${target.rank} of $totalProducts$conditionSuffix.';
    }

    final resultData = await _geminiService.generateRankingExplanation(
      nutrientName: fact.name,
      nutrientUnit: fact.unit,
      thisValue: fact.thisValue,
      bestValue: fact.bestValue,
      worstValue: fact.worstValue,
      rank: target.rank,
      totalProducts: totalProducts,
      healthCondition: conditionName,
      languageCode: languageCode,
    );

    return resultData['explanation'] ??
        'This product ranks ${target.rank} of $totalProducts$conditionSuffix.';
  }

  /// Picks the single most decision-useful nutrient fact to narrate for
  /// [target], considering every nutrient tied to every one of the user's
  /// conditions (via ComparisonCalculator, which already does this
  /// correctly for the main advisory) -- not just [user.conditions.first].
  /// This is supporting detail only; it does NOT decide whether the
  /// wording says "best"/"worst"/"middle" -- that comes from [target.rank]
  /// itself inside generateRankingExplanation, so the sentence can never
  /// contradict the numbered badge shown on the ranking list.
  ({String name, String unit, double thisValue, double bestValue, double worstValue})?
      _primaryComparisonFact({
    required RankedProductResult target,
    required List<RankedProductResult> comparisonSet,
    required UserHealthProfile user,
  }) {
    final facts = ComparisonCalculator.computeFacts(
      target: target.evaluation,
      comparisonSet: comparisonSet.map((r) => r.evaluation).toList(),
      user: user,
    );
    final fact = ComparisonCalculator.primaryFact(facts);
    if (fact == null) return null;

    return (
      name: _getNutrientName(fact.nutrientKey),
      unit: _getNutrientUnit(fact.nutrientKey),
      thisValue: fact.thisValue,
      bestValue: fact.bestValueInSet,
      worstValue: fact.worstValueInSet,
    );
  }

  String _allergenLabel(AllergenType a) {
    switch (a) {
      case AllergenType.shellfish:
        return 'shellfish';
      case AllergenType.fish:
        return 'fish';
      case AllergenType.peanuts:
        return 'peanuts';
      case AllergenType.treeNuts:
        return 'tree nuts';
      case AllergenType.soy:
        return 'soy';
      case AllergenType.dairy:
        return 'dairy';
      case AllergenType.eggs:
        return 'eggs';
      case AllergenType.wheatGluten:
        return 'wheat/gluten';
      case AllergenType.msg:
        return 'MSG';
    }
  }

  String _getNutrientName(String nutrientKey) {
    switch (nutrientKey) {
      case 'sodiumMg':
        return 'sodium';
      case 'sugarsG':
        return 'sugars';
      case 'saturatedFatG':
        return 'saturated fat';
      default:
        return nutrientKey;
    }
  }

  String _getNutrientUnit(String nutrientKey) {
    switch (nutrientKey) {
      case 'sodiumMg':
        return 'mg';
      case 'sugarsG':
      case 'saturatedFatG':
        return 'g';
      default:
        return '';
    }
  }

  String _getConditionName(UserHealthProfile user) {
    if (user.conditions.isEmpty) return '';

    final conditions = user.conditions.map((c) {
      switch (c) {
        case HealthCondition.hypertension:
          return 'hypertension';
        case HealthCondition.diabetes:
          return 'diabetes';
        case HealthCondition.heartCondition:
          return 'heart condition';
      }
    }).toList();

    return conditions.join(', ');
  }
}