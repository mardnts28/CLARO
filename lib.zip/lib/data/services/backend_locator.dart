// lib/data/services/backend_locator.dart
//
// Single place where the health-advisory / ranking / comparison backend
// (lib/core + lib/data) is wired together, so screens don't each construct
// their own ProductRepository/UserRepository/GeminiAdvisoryService.
// Follows the same singleton-via-static-instance pattern ProductDbService
// already uses elsewhere in this app -- no new DI framework introduced.
//
// PHASE 2 CHANGE: added `groupRepository`, registered after
// `userRepository` since it depends on it (see group_repository.dart --
// linked members' health data is fetched through the existing
// UserRepository, not duplicated).

import 'package:flutter_dotenv/flutter_dotenv.dart';

import '../repositories/product_repository.dart';
import '../repositories/user_repository.dart';
import '../repositories/favorites_repository.dart';
import '../repositories/history_repository.dart';
import '../repositories/group_repository.dart'; // NEW (Phase 2)
import 'favorites_service.dart';
import 'gemini_advisory_service.dart';
import 'product_comparison_service.dart';
import 'product_extraction_service.dart';
import 'product_ranking_service.dart';
import 'cloudinary_upload_service.dart';
import '../../services/pending_reports_service.dart';

class BackendLocator {
  BackendLocator._();

  // Read from .env (loaded once in main.dart via dotenv.load()) --
  // pubspec.yaml already lists .env as an asset and flutter_dotenv as a
  // dependency.
  //
  // GEMINI_API_KEY is intentionally NOT read here anymore -- the real key
  // now lives only as a Cloudflare Worker secret (claro-gemini-proxy), never
  // inside the app/APK. The app instead holds GEMINI_PROXY_URL (the
  // Worker's public URL) and APP_SHARED_SECRET (a low-stakes app-to-Worker
  // auth token, rotatable any time, unlike a real API key with paid quota
  // behind it). See gemini_advisory_service.dart's header comment.
  static String get _geminiProxyUrl => dotenv.env['GEMINI_PROXY_URL'] ?? '';
  static String get _appSharedSecret => dotenv.env['APP_SHARED_SECRET'] ?? '';
  static String get _geminiModel =>
      dotenv.env['GEMINI_MODEL'] ?? 'gemini-3.5-flash';

  static String get geminiProxyUrl => _geminiProxyUrl;
  static String get appSharedSecret => _appSharedSecret;
  static String get geminiModel => _geminiModel;

  // Update these key names if your .env uses different variable names --
  // see cloudinary_upload_service.dart's header comment for one-time
  // Cloudinary console setup steps.
  static String get _cloudinaryCloudName =>
      dotenv.env['CLOUDINARY_CLOUD_NAME'] ?? '';
  static String get _cloudinaryUploadPreset =>
      dotenv.env['CLOUDINARY_UPLOAD_PRESET'] ?? '';

  static final ProductRepository productRepository = FirestoreProductRepository();

  static final UserRepository userRepository = FirebaseUserRepository();

  // NEW (Phase 2) -- registered after userRepository so it can be handed
  // in for resolving "linked" members' profiles in
  // getGroupHealthProfiles(). See group_repository.dart.
  static final GroupRepository groupRepository = FirebaseGroupRepository(
    userRepository: userRepository,
  );

  // Backed by Firestore (`users/{userId}/favorites`) -- favorites now
  // persist across app restarts and sync across a user's devices. The
  // heart button (product detail) and the History screen's Favorites tab
  // both read/write through this one instance so they always agree on
  // what's favorited.
  static final FavoritesRepository favoritesRepository = FirebaseFavoritesRepository();

  // The orchestration layer screens should actually call -- wraps
  // favoritesRepository + productRepository together (e.g. for turning
  // favorited productIds into full Product objects). Both the product
  // detail heart button and the History screen's Favorites tab read/write
  // through this one instance so they always agree on what's favorited.
  static final FavoritesService favoritesService = FavoritesService(
    favoritesRepository: favoritesRepository,
    productRepository: productRepository,
  );

  // Backed by Firestore (`users/{userId}/history`) -- scan and comparison
  // records persist across app restarts and sync across a user's devices.
  // HistoryService (services/history_service.dart) wraps this with the
  // in-memory cache + broadcast stream the History screen listens to for
  // UI reactivity, so this instance itself stays a thin Firestore adapter.
  static final HistoryRepository historyRepository = FirebaseHistoryRepository();

  static final GeminiAdvisoryService geminiAdvisoryService =
      GeminiAdvisoryService(
    proxyUrl: _geminiProxyUrl,
    appSecret: _appSharedSecret,
    model: _geminiModel,
  );

  // Gemini's 3rd role in this system (see product_extraction_service.dart) --
  // reads front+back product photos and returns structured brand/nutrition/
  // ingredient/allergen data. Used by the unknown-product report flow
  // (Phase 3) to populate a submission before it reaches admin review.
  static final ProductExtractionService productExtractionService =
      ProductExtractionService(
    proxyUrl: _geminiProxyUrl,
    appSecret: _appSharedSecret,
    model: _geminiModel,
  );

  // Used by the unknown-product report flow to upload front/back label
  // photos before submitting a report -- see cloudinary_upload_service.dart.
  static final CloudinaryUploadService cloudinaryUploadService =
      CloudinaryUploadService(
    cloudName: _cloudinaryCloudName,
    uploadPreset: _cloudinaryUploadPreset,
  );

  static final ProductRankingService productRankingService =
      ProductRankingService(geminiService: geminiAdvisoryService);

  static final ProductComparisonService productComparisonService =
      ProductComparisonService(
    productRepository: productRepository,
    productRankingService: productRankingService,
  );

  static final PendingReportsService pendingReportsService =
      PendingReportsService();
}