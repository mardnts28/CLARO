import 'dart:ui';
import '../data/models/health_profile.dart';
import '../core/utils/number_format_utils.dart';
import '../core/utils/nutrition_calculator.dart';

/// One entry of a product's `available_sizes` array, pairing a package
/// size (in grams) with the Cloudinary photo of THAT specific package,
/// when one has been uploaded. [imageUrl] is null for sizes that don't
/// have their own photo yet -- callers should fall back to
/// [Product.imageUrl] (the product's default/primary image) in that case.
class ProductSizeOption {
  final double sizeGrams;
  final String? imageUrl;

  const ProductSizeOption({required this.sizeGrams, this.imageUrl});

  Map<String, dynamic> toJson() => {
    'sizeGrams': sizeGrams,
    'imageUrl': imageUrl,
  };

  factory ProductSizeOption.fromJson(Map<String, dynamic> json) =>
      ProductSizeOption(
        sizeGrams: (json['sizeGrams'] as num?)?.toDouble() ?? 0.0,
        imageUrl: json['imageUrl'] as String?,
      );
}

class Product {
  final String id;
  final String name;
  final String brand;
  final String variant;
  final String category;
  final String imageUrl;
  final String fdaStatus;            // 'ACTIVE', 'EXPIRED', 'UNVERIFIED'
  final String fdaRegistrationNumber;
  final String fdaValidityDate;      // NEW: e.g. "2027-12-31"
  final String fdaManufacturer;      // NEW
  final String cprNumber;            // NEW: Certificate of Product Registration
  final List<String> allergens;
  final List<String> ingredients;
  final String servingInstructions;
  final List<double> availableSizes;
  // Size -> image pairing parsed from the same `available_sizes` Firestore
  // field as [availableSizes] (see product_repository.dart's
  // _productFromDoc). Kept as a separate list rather than folded into
  // [availableSizes] so every existing caller of the plain-number list
  // (nutrition scaling, etc.) keeps working unchanged.
  final List<ProductSizeOption> sizeOptions;
  final NutritionalFacts nutritionalFacts;
  final bool isOfflineFallback;

  Product({
    required this.id,
    required this.name,
    required this.brand,
    this.variant = '',
    this.category = '',
    this.imageUrl = '',
    this.fdaStatus = 'UNVERIFIED',
    this.fdaRegistrationNumber = '',
    this.fdaValidityDate = '',
    this.fdaManufacturer = '',
    this.cprNumber = '',
    this.allergens = const [],
    this.ingredients = const [],
    this.servingInstructions = '',
    this.availableSizes = const [],
    this.sizeOptions = const [],
    required this.nutritionalFacts,
    this.isOfflineFallback = false,
  });

  /// Image to show for [sizeGrams], falling back to [imageUrl] (the
  /// product's default photo) when that size has no photo of its own yet.
  String imageUrlForSize(double sizeGrams) {
    for (final option in sizeOptions) {
      if (option.sizeGrams == sizeGrams && (option.imageUrl?.isNotEmpty ?? false)) {
        return option.imageUrl!;
      }
    }
    return imageUrl;
  }

  /// Returns a copy with the given fields replaced. Used to merge data from
  /// a secondary source (e.g. OCR + Gemini nutrition extraction) onto a
  /// product that already carries FDA-sourced fields (id, imageUrl,
  /// fdaStatus, cprNumber, etc.) without discarding those fields.
  Product copyWith({
    String? id,
    String? name,
    String? brand,
    String? variant,
    String? category,
    String? imageUrl,
    String? fdaStatus,
    String? fdaRegistrationNumber,
    String? fdaValidityDate,
    String? fdaManufacturer,
    String? cprNumber,
    List<String>? allergens,
    List<String>? ingredients,
    String? servingInstructions,
    List<double>? availableSizes,
    List<ProductSizeOption>? sizeOptions,
    NutritionalFacts? nutritionalFacts,
    bool? isOfflineFallback,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      brand: brand ?? this.brand,
      variant: variant ?? this.variant,
      category: category ?? this.category,
      imageUrl: imageUrl ?? this.imageUrl,
      fdaStatus: fdaStatus ?? this.fdaStatus,
      fdaRegistrationNumber: fdaRegistrationNumber ?? this.fdaRegistrationNumber,
      fdaValidityDate: fdaValidityDate ?? this.fdaValidityDate,
      fdaManufacturer: fdaManufacturer ?? this.fdaManufacturer,
      cprNumber: cprNumber ?? this.cprNumber,
      allergens: allergens ?? this.allergens,
      ingredients: ingredients ?? this.ingredients,
      servingInstructions: servingInstructions ?? this.servingInstructions,
      availableSizes: availableSizes ?? this.availableSizes,
      sizeOptions: sizeOptions ?? this.sizeOptions,
      nutritionalFacts: nutritionalFacts ?? this.nutritionalFacts,
      isOfflineFallback: isOfflineFallback ?? this.isOfflineFallback,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'brand': brand,
    'variant': variant,
    'category': category,
    'imageUrl': imageUrl,
    'fdaStatus': fdaStatus,
    'fdaRegistrationNumber': fdaRegistrationNumber,
    'fdaValidityDate': fdaValidityDate,
    'fdaManufacturer': fdaManufacturer,
    'cprNumber': cprNumber,
    'allergens': allergens,
    'ingredients': ingredients,
    'servingInstructions': servingInstructions,
    'availableSizes': availableSizes,
    'sizeOptions': sizeOptions.map((s) => s.toJson()).toList(),
    'nutritionalFacts': nutritionalFacts.toJson(),
    'isOfflineFallback': isOfflineFallback,
  };

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    id: json['id']?.toString() ?? '',
    name: json['name']?.toString() ?? '',
    brand: json['brand']?.toString() ?? '',
    variant: json['variant']?.toString() ?? '',
    category: json['category']?.toString() ?? '',
    imageUrl: json['imageUrl']?.toString() ?? '',
    fdaStatus: json['fdaStatus']?.toString() ?? 'UNVERIFIED',
    fdaRegistrationNumber: json['fdaRegistrationNumber']?.toString() ?? '',
    fdaValidityDate: json['fdaValidityDate']?.toString() ?? '',
    fdaManufacturer: json['fdaManufacturer']?.toString() ?? '',
    cprNumber: json['cprNumber']?.toString() ?? '',
    allergens: List<String>.from(
        (json['allergens'] as List? ?? []).map((e) => e.toString())),
    ingredients: List<String>.from(
        (json['ingredients'] as List? ?? []).map((e) => e.toString())),
    servingInstructions: json['servingInstructions']?.toString() ?? '',
    availableSizes: (json['availableSizes'] as List? ?? [])
        .map((s) => (s as num).toDouble())
        .toList(),
    sizeOptions: (json['sizeOptions'] as List? ?? [])
        .whereType<Map<String, dynamic>>()
        .map((s) => ProductSizeOption.fromJson(s))
        .toList(),
    nutritionalFacts: json['nutritionalFacts'] != null
        ? NutritionalFacts.fromJson(
            json['nutritionalFacts'] as Map<String, dynamic>)
        : NutritionalFacts(),
    isOfflineFallback: json['isOfflineFallback'] as bool? ?? false,
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Product && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}

class NutritionalFacts {
  final String servingSize;
  final String servingsPerContainer;
  final double caloriesKcal;
  final double proteinG;
  final double carbsG;
  final double totalFatG;
  final double saturatedFatG;
  final double transFatG;
  final double cholesterolMg;
  final double sodiumMg;
  final double potassiumMg;
  final double calciumMg;
  final double ironMg;
  final double fiberG;
  final double sugarsG;
  final double addedSugarsG;

  /// True once real nutrition data has been found for this product (via the
  /// OCR + Gemini extraction pipeline). False means the numeric fields above
  /// are just unset defaults (0), not a confirmed "this product has 0g of
  /// everything" -- the UI should show an "unavailable" state rather than
  /// the zero values in that case.
  final bool hasNutritionData;

  // Computed getters for UI rendering (retains compatibility with old fields)
  String get calories => '${NumberFormatUtils.formatValue(caloriesKcal)} kcal';
  String get totalFat => '${NumberFormatUtils.formatValue(totalFatG)}g';
  String get saturatedFat => '${NumberFormatUtils.formatValue(saturatedFatG)}g';
  String get transFat => '${NumberFormatUtils.formatValue(transFatG)}g';
  String get cholesterol => '${NumberFormatUtils.formatValue(cholesterolMg)}mg';
  String get sodium => '${NumberFormatUtils.formatValue(sodiumMg)}mg';
  String get totalCarbohydrate => '${NumberFormatUtils.formatValue(carbsG)}g';
  String get dietaryFiber => '${NumberFormatUtils.formatValue(fiberG)}g';
  String get sugars => '${NumberFormatUtils.formatValue(sugarsG)}g';
  String get protein => '${NumberFormatUtils.formatValue(proteinG)}g';

  NutritionalFacts({
    this.servingSize = '',
    this.servingsPerContainer = '',
    double? caloriesKcal,
    double? proteinG,
    double? carbsG,
    double? totalFatG,
    double? saturatedFatG,
    double? transFatG,
    double? cholesterolMg,
    double? sodiumMg,
    double? potassiumMg,
    double? calciumMg,
    double? ironMg,
    double? fiberG,
    double? sugarsG,
    double? addedSugarsG,

    // Legacy parameters to support existing database without editing 1500 lines:
    String? calories,
    String? totalFat,
    String? saturatedFat,
    String? transFat,
    String? cholesterol,
    String? sodium,
    String? totalCarbohydrate,
    String? dietaryFiber,
    String? sugars,
    String? protein,
    bool? hasNutritionData,
  })  : caloriesKcal = caloriesKcal ?? (calories != null ? double.tryParse(calories.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0),
        proteinG = proteinG ?? (protein != null ? double.tryParse(protein.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0),
        carbsG = carbsG ?? (totalCarbohydrate != null ? double.tryParse(totalCarbohydrate.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0),
        totalFatG = totalFatG ?? (totalFat != null ? double.tryParse(totalFat.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0),
        saturatedFatG = saturatedFatG ?? (saturatedFat != null ? double.tryParse(saturatedFat.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0),
        transFatG = transFatG ?? (transFat != null ? double.tryParse(transFat.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0),
        cholesterolMg = cholesterolMg ?? (cholesterol != null ? double.tryParse(cholesterol.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0),
        sodiumMg = sodiumMg ?? (sodium != null ? double.tryParse(sodium.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0),
        potassiumMg = potassiumMg ?? 0.0,
        calciumMg = calciumMg ?? 0.0,
        ironMg = ironMg ?? 0.0,
        fiberG = fiberG ?? (dietaryFiber != null ? double.tryParse(dietaryFiber.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0),
        sugarsG = sugarsG ?? (sugars != null ? double.tryParse(sugars.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0),
        addedSugarsG = addedSugarsG ?? 0.0,
        hasNutritionData = hasNutritionData ??
            ((caloriesKcal ?? (calories != null ? double.tryParse(calories.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0)) > 0 ||
             (proteinG ?? (protein != null ? double.tryParse(protein.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0)) > 0 ||
             (totalFatG ?? (totalFat != null ? double.tryParse(totalFat.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0)) > 0 ||
             (sodiumMg ?? (sodium != null ? double.tryParse(sodium.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0)) > 0 ||
             (carbsG ?? (totalCarbohydrate != null ? double.tryParse(totalCarbohydrate.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0)) > 0 ||
             (sugarsG ?? (sugars != null ? double.tryParse(sugars.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0.0 : 0.0)) > 0);

  Map<String, dynamic> toJson() => {
    'servingSize': servingSize,
    'servingsPerContainer': servingsPerContainer,
    'caloriesKcal': caloriesKcal,
    'proteinG': proteinG,
    'carbsG': carbsG,
    'totalFatG': totalFatG,
    'saturatedFatG': saturatedFatG,
    'transFatG': transFatG,
    'cholesterolMg': cholesterolMg,
    'sodiumMg': sodiumMg,
    'potassiumMg': potassiumMg,
    'calciumMg': calciumMg,
    'ironMg': ironMg,
    'fiberG': fiberG,
    'sugarsG': sugarsG,
    'addedSugarsG': addedSugarsG,
    'hasNutritionData': hasNutritionData,
  };

  factory NutritionalFacts.fromJson(Map<String, dynamic> json) {
    final cal = (json['caloriesKcal'] as num?)?.toDouble() ?? 0.0;
    final prot = (json['proteinG'] as num?)?.toDouble() ?? 0.0;
    final carb = (json['carbsG'] as num?)?.toDouble() ?? 0.0;
    final fat = (json['totalFatG'] as num?)?.toDouble() ?? 0.0;
    final satFat = (json['saturatedFatG'] as num?)?.toDouble() ?? 0.0;
    final trans = (json['transFatG'] as num?)?.toDouble() ?? 0.0;
    final chol = (json['cholesterolMg'] as num?)?.toDouble() ?? 0.0;
    final sod = (json['sodiumMg'] as num?)?.toDouble() ?? 0.0;
    final pot = (json['potassiumMg'] as num?)?.toDouble() ?? 0.0;
    final calc = (json['calciumMg'] as num?)?.toDouble() ?? 0.0;
    final iron = (json['ironMg'] as num?)?.toDouble() ?? 0.0;
    final fib = (json['fiberG'] as num?)?.toDouble() ?? 0.0;
    final sug = (json['sugarsG'] as num?)?.toDouble() ?? 0.0;
    final addSug = (json['addedSugarsG'] as num?)?.toDouble() ?? 0.0;
    final explicit = json['hasNutritionData'] as bool?;
    final hasData = explicit ?? (cal > 0 || prot > 0 || fat > 0 || sod > 0 || carb > 0 || sug > 0);

    return NutritionalFacts(
      servingSize: json['servingSize']?.toString() ?? '',
      servingsPerContainer: json['servingsPerContainer']?.toString() ?? '',
      caloriesKcal: cal,
      proteinG: prot,
      carbsG: carb,
      totalFatG: fat,
      saturatedFatG: satFat,
      transFatG: trans,
      cholesterolMg: chol,
      sodiumMg: sod,
      potassiumMg: pot,
      calciumMg: calc,
      ironMg: iron,
      fiberG: fib,
      sugarsG: sug,
      addedSugarsG: addSug,
      hasNutritionData: hasData,
    );
  }
}

class DetectionResult {
  final String label;
  final double confidence;
  final Rect boundingBox;

  DetectionResult({
    required this.label,
    required this.confidence,
    required this.boundingBox,
  });
}

// ============================================================================
// Backend Compatibility Extensions
// ============================================================================
// These extensions provide the fields and structure expected by the backend
// logic (lib/core and lib/data) while keeping product_model.dart as the
// single source of truth for product data.

/// NutritionInfo class expected by backend logic (per-100g values)
class NutritionInfo {
  final double caloriesKcal;
  final double sodiumMg;
  final double sugarsG;
  final double saturatedFatG;
  final double totalCarbohydratesG;
  final double dietaryFiberG;
  final double potassiumMg;
  final double totalFatG;
  final double proteinG;

  const NutritionInfo({
    required this.caloriesKcal,
    required this.sodiumMg,
    required this.sugarsG,
    required this.saturatedFatG,
    required this.totalCarbohydratesG,
    required this.dietaryFiberG,
    required this.potassiumMg,
    required this.totalFatG,
    required this.proteinG,
  });
}

/// Extension on Product to provide backend-compatible fields
extension ProductBackendAdapter on Product {
  /// Parses serving size string to extract grams (e.g., "56g" -> 56.0)
  double get servingSizeG {
    final regex = RegExp(r'(\d+(?:\.\d+)?)\s*[gG]');
    final match = regex.firstMatch(nutritionalFacts.servingSize);
    if (match == null) return 0.0;
    return double.tryParse(match.group(1) ?? '') ?? 0.0;
  }

  /// Calculates per-100g nutrition values from per-serving values
  NutritionInfo get nutritionPer100g {
    final per100g = nutritionalFacts.per100gValues;
    if (per100g == null) {
      // Fallback: return per-serving values if calculation fails
      return NutritionInfo(
        caloriesKcal: nutritionalFacts.caloriesKcal,
        sodiumMg: nutritionalFacts.sodiumMg,
        sugarsG: nutritionalFacts.sugarsG,
        saturatedFatG: nutritionalFacts.saturatedFatG,
        totalCarbohydratesG: nutritionalFacts.carbsG,
        dietaryFiberG: nutritionalFacts.fiberG,
        potassiumMg: nutritionalFacts.potassiumMg,
        totalFatG: nutritionalFacts.totalFatG,
        proteinG: nutritionalFacts.proteinG,
      );
    }
    return NutritionInfo(
      caloriesKcal: per100g['caloriesKcal'] ?? nutritionalFacts.caloriesKcal,
      sodiumMg: per100g['sodiumMg'] ?? nutritionalFacts.sodiumMg,
      sugarsG: per100g['sugarsG'] ?? nutritionalFacts.sugarsG,
      saturatedFatG: per100g['saturatedFatG'] ?? nutritionalFacts.saturatedFatG,
      totalCarbohydratesG: per100g['carbsG'] ?? nutritionalFacts.carbsG,
      dietaryFiberG: per100g['fiberG'] ?? nutritionalFacts.fiberG,
      potassiumMg: per100g['potassiumMg'] ?? nutritionalFacts.potassiumMg,
      totalFatG: per100g['totalFatG'] ?? nutritionalFacts.totalFatG,
      proteinG: per100g['proteinG'] ?? nutritionalFacts.proteinG,
    );
  }

  /// Converts string allergens to AllergenType enums
  List<AllergenType> get containsAllergens {
    return allergens.map((allergenStr) {
      final normalized = allergenStr.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
      switch (normalized) {
        case 'fish':
        case 'isda':
          return AllergenType.fish;
        case 'milk':
        case 'gatas':
          return AllergenType.dairy;
        case 'egg':
        case 'itlog':
          return AllergenType.eggs;
        case 'soy':
        case 'soya':
        case 'soybean':
          return AllergenType.soy;
        case 'wheat':
        case 'trigo':
          return AllergenType.wheatGluten;
        case 'shellfish':
        case 'lamangdagat':
        case 'lamang-dagat':
          return AllergenType.shellfish;
        case 'peanut':
        case 'mani':
          return AllergenType.peanuts;
        default:
          return AllergenType.msg; // Fallback for unrecognized allergens
      }
    }).toList();
  }

  /// Use variant as subCategory for backend compatibility
  String get subCategory => variant;

  /// Convert string FDA status to enum-like behavior
  String get fdaStatusBackend => fdaStatus;
}