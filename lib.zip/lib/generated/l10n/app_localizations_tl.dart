// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Tagalog (`tl`).
class AppLocalizationsTl extends AppLocalizations {
  AppLocalizationsTl([String locale = 'tl']) : super(locale);

  @override
  String greeting(Object name) {
    return 'Kumusta, $name! 👋';
  }

  @override
  String get home => 'Home';

  @override
  String get scan => 'I-scan';

  @override
  String get history => 'Kasaysayan';

  @override
  String get profile => 'Profile';

  @override
  String get homeTagline => 'Gawing mas matalino ang pamimili ngayon.';

  @override
  String get scanCardTitle => 'I-scan ang produkto';

  @override
  String get scanCardSubtitle =>
      'Itapat ang iyong camera sa anumang instant noodles o de-latang pagkain.';

  @override
  String get scanNow => 'I-scan na';

  @override
  String get labelIntroTitle => 'Kilalanin ang iyong mga label';

  @override
  String get labelIntroSubtitle =>
      'Sa tulong ng CLARO, mas madaling maunawaan ang mga label at pumili ng mas malusog na opsyon.';

  @override
  String get healthGradeTitle => 'Sukat ng kalusugan ng pagkain';

  @override
  String get healthGradeSubtitle =>
      'Kabuuang kalidad ng nutrisyon ng produkto.';

  @override
  String get healthGradeValue0 => 'Pinakamainam – Mataas ang sustansya';

  @override
  String get healthGradeValue1 => 'Rekomendadong pagpipilian';

  @override
  String get healthGradeValue2 => 'Katanggap-tanggap sa katamtamang dami';

  @override
  String get healthGradeValue3 => 'Limitahan ang pagkonsumo';

  @override
  String get healthGradeValue4 => 'Iwasan ang madalas na pagkonsumo';

  @override
  String get ecoGradeTitle => 'Grado ng pagiging maka-kalikasan';

  @override
  String get ecoGradeSubtitle => 'Epekto ng produkto sa planeta.';

  @override
  String get ecoGradeValue0 => 'Napakahusay na epekto sa kapaligiran';

  @override
  String get ecoGradeValue1 => 'Mabuti para sa kapaligiran';

  @override
  String get ecoGradeValue2 => 'Katamtamang epekto sa kapaligiran';

  @override
  String get ecoGradeValue3 => 'Isaalang-alang ang ibang opsyon';

  @override
  String get ecoGradeValue4 => 'Malaking pinsala sa kapaligiran';

  @override
  String get processGradeTitle => 'Antas ng pagpoproseso ng pagkain';

  @override
  String get processGradeSubtitle => 'Gaano kalalim naproseso ang produkto.';

  @override
  String get processGroupFirst => 'Unang grado';

  @override
  String get processGroupFourth => 'Ika-apat na grado';

  @override
  String get processLabel0 => 'Hindi o bahagyang naproseso';

  @override
  String get processLabel1 => 'Naprosesong sangkap sa pagluluto';

  @override
  String get processLabel2 => 'Naprosesong pagkain';

  @override
  String get processLabel3 => 'Ultra-proseso na pagkain';

  @override
  String get bestLabel => 'Pinaka-inirerekomenda';

  @override
  String get worstLabel => 'Pinaka-hindi inirerekomenda';

  @override
  String get scanTabTitle => 'I-scan';

  @override
  String get scanTabSubtitle => 'I-scan ang iyong produkto mula rito.';

  @override
  String get historyTabTitle => 'Kasaysayan';

  @override
  String get historyTabSubtitle =>
      'Makikita mo rito ang iyong history ng pag-scan.';

  @override
  String get welcomeBack => 'Welcome back!';

  @override
  String get loginToContinue => 'Login to continue';

  @override
  String get email => 'Email';

  @override
  String get password => 'Password';

  @override
  String get forgotPassword => 'Nakalimutan ang password?';

  @override
  String get login => 'Mag-login';

  @override
  String get orContinueWith => 'or continue with';

  @override
  String get continueWithGoogle => 'Magpatuloy gamit ang Google';

  @override
  String get dontHaveAccount => 'Wala pang account?';

  @override
  String get signUp => 'Mag-sign up';

  @override
  String get chooseLanguage => 'Piliin ang Lenggwuahe';

  @override
  String get english => 'English';

  @override
  String get tagalog => 'Tagalog';

  @override
  String get passwordRequired => 'Kinakailangan ang password';

  @override
  String get invalidEmailOrPassword => 'Invalid email o password';

  @override
  String get unableSendVerificationCode =>
      'Hindi maipadala ang verification code. Pakisubukang muli.';

  @override
  String get personalInfo => 'Personal na Impormasyon';

  @override
  String get preference => 'Preference';

  @override
  String get language => 'Lenggwuahe';

  @override
  String get suggestion => 'Pagsusuri ng App';

  @override
  String get aboutClaro => 'Tungkol sa CLARO';

  @override
  String get logout => 'Logout';

  @override
  String get theme => 'Tema';

  @override
  String get themeSaved => 'Tema na-save';

  @override
  String get themeSaveError => 'Hindi ma-save ang tema';

  @override
  String get themeDefault => 'Default';

  @override
  String get themeDarkMode => 'Dark Mode';

  @override
  String get themeDefaultDescription => 'Karaniwang hitsura ng Claro';

  @override
  String get themeDarkModeDescription =>
      'Madilim na background para sa mga lugar na may mababang ilaw.';

  @override
  String get multiFactorAuthentication => 'Multi-factor authentication';

  @override
  String get voiceAssistant => 'Voice Assistant';

  @override
  String get darkModeSetting => 'Dark Mode';

  @override
  String get mfaSaveError => 'Hindi ma-save ang MFA setting';

  @override
  String get preferenceSaveError => 'Hindi ma-save ang preference';

  @override
  String get preferenceTitle => 'Preference';

  @override
  String get voiceSoundTitle => 'Boses at tunog';

  @override
  String get selectLanguage => 'Piliin ang wika';

  @override
  String get speechRate => 'Bilis ng pagsasalita';

  @override
  String get previewAudio => 'I-tap para sa preview ng audio';

  @override
  String get vibrationFeedback => 'Vibration feedback';

  @override
  String get vibrateDescription =>
      'Mag-vibrate sa pag-scan, alerto, at pagbabasa';

  @override
  String get textSize => 'Laki ng teksto';

  @override
  String get previewAudioShort => 'Preview ng audio';

  @override
  String get signUpWelcome => 'Welcome!';

  @override
  String get signUpSubtitle => 'Mag-sign up upang makapagsimula';

  @override
  String get alreadyHaveAccount => 'Mayroon ka nang account?';

  @override
  String get resetPassword => 'I-reset ang password';

  @override
  String get resetPasswordInfo =>
      'Ilagay ang iyong email at magpapadala kami ng link para i-reset ang iyong password.';

  @override
  String get sendResetLink => 'Magpadala ng reset link';

  @override
  String get emailSent => 'Email naipadala';

  @override
  String get checkYourEmail => 'Suriin ang iyong email';

  @override
  String get followLink =>
      'Sundan ang link sa iyong email upang i-reset ang password.';

  @override
  String get backToLogin => 'Bumalik sa pag-login';

  @override
  String get rememberYourPassword => 'Naalala mo na ba ang iyong password?';

  @override
  String get verifyEmail => 'I-verify ang iyong email';

  @override
  String get verificationSentInfo =>
      'May verification code na ipinadala sa iyong email.';

  @override
  String get enterCodeHint => 'Ilagay ang 6-digit na code';

  @override
  String get verify => 'I-verify';

  @override
  String get resendCode => 'Muling ipadala ang code';

  @override
  String resendInSeconds(Object seconds) {
    return 'Muling ipadala sa $seconds s';
  }

  @override
  String get canResendNow => 'Maaari mo nang muling ipadala';

  @override
  String attemptsUsed(Object used) {
    return 'Ginamit na pagtatangka: $used/5';
  }

  @override
  String get tooManyFailedAttempts =>
      'Masyadong maraming nabigong pagtatangka. Mangyaring mag-login muli.';

  @override
  String get unableToResend => 'Hindi ma-resend ang verification code.';

  @override
  String get verificationCodeSent =>
      'May bagong verification code na ipinadala.';

  @override
  String get onboardingNamePrompt => 'Ano ang gusto mong itawag namin sa iyo?';

  @override
  String get onboardingNameHint => 'Pangalan';

  @override
  String get onboardingNameEmpty => 'Pakisulat ang iyong pangalan.';

  @override
  String get onboardingHeadline => 'Malinaw. Lokal. Maaasahan.';

  @override
  String get onboardingSubheadline =>
      'Ang iyong AI na katulong para sa mas malusog na pamimili.';

  @override
  String get featureScan => 'I-scan ang produkto';

  @override
  String get featureNutrition => 'Nutrisyon ng produkto';

  @override
  String get featureHealth => 'Gabay sa kalusugan';

  @override
  String get featureCompare => 'Paghahambing ng produkto';

  @override
  String get getStarted => 'Magsimula';

  @override
  String get onboardingInstructions =>
      'Sagutan ang mga sumusunod para sa mas ligtas at mas personalized na rekomendasyon.';

  @override
  String get conditionsQuestion => 'May kondisyon ka ba sa kalusugan?';

  @override
  String get chooseAllThatApply => 'Pumili ng lahat ng naaangkop.';

  @override
  String get profileChangeNote =>
      'Maaari mo itong baguhin sa iyong profile settings.';

  @override
  String get allergensQuestion => 'May mga allergen bang dapat iwasan?';

  @override
  String get safetyPriorityTitle => 'Prayoridad namin ang iyong kaligtasan';

  @override
  String get safetyPriorityMessage =>
      'Gagamitin namin ang impormasyong ito upang magbigay ng health insights at mas ligtas na rekomendasyon.';

  @override
  String get suggestionIntro => 'Gusto naming marinig ang iyong feedback.';

  @override
  String get rateYourExperience => 'I-rate ang iyong karanasan';

  @override
  String get shareImprovement => 'Ibahagi kung ano ang maaari naming i-improve';

  @override
  String get submit => 'Ipadala';

  @override
  String get sending => 'Ipinapadala...';

  @override
  String get suggestionSentTitle => 'Naipadalang feedback!';

  @override
  String get suggestionSentBody =>
      'Salamat! Matagumpay na naipadala ang iyong feedback.';

  @override
  String get backLabel => 'Bumalik';

  @override
  String get needSignInToSubmit =>
      'Mangyaring mag-sign in bago magpadala ng suhestiyon.';

  @override
  String get submitError => 'May error sa pagpapadala';

  @override
  String get aboutClaroHeading => 'Alamin ang tungkol sa amin!';

  @override
  String get aboutClaroDescription =>
      'Ang CLARO ay isang AI-powered mobile app na tumutulong sa mga mamimili ng groceries na maunawaan ang impormasyon sa nutrisyon ng lokal na de-latang pagkain. Sa pamamagitan ng pag-scan ng produkto, makikita ng mga user ang pinasimpleng nutrition summaries, health advisories, allergen warnings, product comparisons, at accessibility features tulad ng voice assistance para makapili ng mas matalino at mas malusog na desisyon sa pagbili.';

  @override
  String get aboutDevelopers => 'Tungkol sa mga developer';

  @override
  String get profileUpdateSuccess => 'Na-update ang profile';

  @override
  String get profileUpdateError => 'Hindi ma-save ang mga update';

  @override
  String get editName => 'I-edit ang pangalan';

  @override
  String get editAge => 'I-edit ang edad';

  @override
  String get cancel => 'Kanselahin';

  @override
  String get save => 'I-save';

  @override
  String get ageLabel => 'Edad';

  @override
  String get none => 'Wala';

  @override
  String get healthConditions => 'Kondisyon sa Kalusugan';

  @override
  String get allergensLabel => 'Allergens';

  @override
  String get accountSettings => 'Account Settings';

  @override
  String get changePassword => 'Baguhin ang password';

  @override
  String get selectAllergen => 'Pumili ng Allergen';

  @override
  String get ratePrompt => 'Mangyaring pumili ng rating sa pagitan ng 1 at 5.';

  @override
  String get suggestionEmpty =>
      'Mangyaring ilagay ang iyong suhestiyon bago ipadala.';

  @override
  String get suggestionTooLong =>
      'Ang suhestiyon ay dapat 500 characters o mas mababa pa.';

  @override
  String get suggestionHint => 'Isulat ang iyong mungkahi dito...';

  @override
  String get clearAllTitle => 'Burahin ang Lahat?';

  @override
  String get clearAllConfirm =>
      'Mabubura ang lahat ng kasaysayan ng iyong mga scan. Hindi ito maibabalik.';

  @override
  String get clear => 'Burahin';

  @override
  String get clearAll => 'Burahin Lahat';

  @override
  String get searchHint => 'Maghanap';

  @override
  String get tabAll => 'Lahat';

  @override
  String get tabFavorites => 'Paborito';

  @override
  String get tabCompare => 'Kumpara';

  @override
  String get emptyFavorites =>
      'Wala pang mga paboritong produkto. I-tap ang ❤️ upang mag-save.';

  @override
  String get emptyComparisons => 'Wala pang mga pag-uugnayan ng produkto.';

  @override
  String noSearchResults(String query) {
    return 'Walang resulta para sa \"$query\"';
  }

  @override
  String get emptyHistory =>
      'Wala pang kasaysayan ng scan. I-scan ang isang produkto upang magsimula!';

  @override
  String get resultsTitle => 'Resulta';

  @override
  String get rankedBySuitability => 'Naka-rank batay sa suitability';

  @override
  String get profileFeatureSoon => 'Parating na ang mga feature ng Profile!';

  @override
  String get fdaExpiredWarning =>
      'BABALA: Ang produktong ito ay may EXPIRED na FDA registration. Maaaring hindi ito ligtas.';

  @override
  String get fdaUnverifiedWarning =>
      'Ang produktong ito ay hindi pa nabeberipika ng FDA Philippines.';

  @override
  String get ageRequirementBadge => '3+ yrs old';

  @override
  String get safeToConsume => 'LIGTAS I-KONSUMO';

  @override
  String get safeToConsumeSubtitle =>
      'Pinakamainam kainin sa katamtamang dami dahil mas mataas sa taba at calories.';

  @override
  String get reminderLabel => 'Paalala';

  @override
  String get diabetesSafeReminder =>
      'Angkop para sa mga may diabetes, ngunit ang madalas na pagkonsumo ay maaaring hindi mainam para sa mga nagkokontrol ng kolesterol o calorie intake.';

  @override
  String containsAllergens(String list) {
    return 'Naglalaman ng $list';
  }

  @override
  String get personalHealthWarningTitle => '🩺 Babala Batay sa Iyong Kalusugan';

  @override
  String get servingRecommendation =>
      '½–¾ ng lata (90–135g) sa bawat meal, maaaring kainin 2–3 beses kada linggo.';

  @override
  String get moreDetailsLink => 'Higit pang detalye';

  @override
  String get totalNutritionTitle => 'Kabuuang Nutrisyon';

  @override
  String get nutriCalories => 'Calories';

  @override
  String get nutriSodium => 'Sodium';

  @override
  String get nutriSugar => 'Sugar';

  @override
  String get nutriProtein => 'Protina';

  @override
  String get nutriTotalFat => 'Total Fat';

  @override
  String get nutriSatFat => 'Sat. Fat';

  @override
  String get nutriTransFat => 'Trans Fat';

  @override
  String get nutriFiber => 'Fiber';

  @override
  String get nutriPotassium => 'Potassium';

  @override
  String get nutriCalcium => 'Calcium';

  @override
  String get nutriIron => 'Iron';

  @override
  String get scoresTitle => 'Grado';

  @override
  String get scoreNutrition => 'Nutrisyon';

  @override
  String get scoreNutritionDesc =>
      'Magandang pinagkukunan ng protina ngunit mas mataas sa taba at calories.';

  @override
  String get scoreEnvironment => 'Kalikasan';

  @override
  String get scoreEnvironmentDesc => 'Moderate environmental impact.';

  @override
  String get scoreProcess => 'Proseso';

  @override
  String get scoreProcessDesc =>
      'Processed food with relatively simple ingredients.';

  @override
  String get compareButton => 'Ihambing';

  @override
  String get similarProductsTitle => 'Pagraranggo ng Produkto';

  @override
  String productCount(int count) {
    return '$count produkto';
  }

  @override
  String get noProductsFound => 'Walang nahanap';

  @override
  String get noSearchMatchDesc =>
      'Walang mga produktong tumutugma sa iyong paghahanap.';

  @override
  String get scanGuideText => 'I-align ang label ng produkto upang i-scan';

  @override
  String get productCapturedBadge => 'Nakuha na ang Produkto!';

  @override
  String get tapToScanHint => 'I-tap kahit saan para i-scan';

  @override
  String get productNotRecognizedTitle => 'Hindi Kilalang Produkto';

  @override
  String get productNotRecognizedDesc =>
      'Hindi nakilala ang produkto. Gusto mo bang ipadala ito para sa pagsusuri?';

  @override
  String get tryAgainButton => 'Subukan Muli';

  @override
  String get submitLabel => 'Ipadala';

  @override
  String get submitSkuHeader => 'IPADALA ANG HINDI KILALANG SKU';

  @override
  String get trainModelHeadline => 'Tulungan Kaming Sanayin ang Model';

  @override
  String get trainModelSubtitle =>
      'Kung hindi na-detect ang produkto, i-upload ang photo at impormasyon nito. Ginagamit ito para ma-improve ang aming engine.';

  @override
  String get imageCaptureSuccess => 'Matagumpay na nakuha ang mock image!';

  @override
  String get imageRequiredError =>
      'Mangyaring kumuha muna ng larawan ng label.';

  @override
  String get submissionReceivedTitle => 'Natanggap na ang Ipinadala';

  @override
  String get submissionReceivedDesc =>
      'Salamat! Susuriin ng aming AI team ang label at ia-update ang database sa loob ng 24 oras.';

  @override
  String get returnToScanner => 'Bumalik sa Scanner';

  @override
  String get labelImageAttached => 'May nakalakip na larawan';

  @override
  String get tapToReplace => 'I-tap para palitan ang photo';

  @override
  String get captureProductLabel => 'Kumuha ng Larawan ng Label';

  @override
  String get ensureReadableNote =>
      'Siguraduhing nababasa ang text at nutrition facts';

  @override
  String get productNameLabel => 'Pangalan ng Produkto / Deskripsyon';

  @override
  String get productNameEmpty => 'Pakilagay ang pangalan ng produkto';

  @override
  String get brandNameLabel => 'Brand (hal. Century, Ligo, Lucky Me)';

  @override
  String get brandNameEmpty => 'Pakilagay ang brand';

  @override
  String get productVariantLabel => 'Variant (hal. Hot & Spicy, Sweet & Sour)';

  @override
  String get productVariantEmpty => 'Pakilagay ang variant';

  @override
  String get productCategoryLabel => 'Kategorya';

  @override
  String get ingredientsListLabel => 'Listahan ng Sangkap (Opsiyonal)';

  @override
  String get submitTrainingButton => 'IPADALA PARA SA TRAINING';

  @override
  String get bestLabelShort => 'Best';

  @override
  String get worstLabelShort => 'Worst';
}
