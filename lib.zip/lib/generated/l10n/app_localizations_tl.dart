// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Tagalog (`tl`).
class AppLocalizationsTl extends AppLocalizations {
  AppLocalizationsTl([String locale = 'tl']) : super(locale);

  @override
  String greeting(Object name) {
    return 'Kumusta, $name! 👋';
  }

  @override
  String get home => 'Home';

  @override
  String get scan => 'I-scan';

  @override
  String get history => 'Kasaysayan';

  @override
  String get profile => 'Profile';

  @override
  String get homeTagline => 'Gawing mas matalino ang pamimili ngayon.';

  @override
  String get scanCardTitle => 'I-scan ang produkto';

  @override
  String get scanCardSubtitle =>
      'Itapat ang iyong camera sa anumang instant noodles o de-latang pagkain.';

  @override
  String get scanNow => 'I-scan na';

  @override
  String get infoFdaTitle => 'Basahin ang label';

  @override
  String get infoFdaSubtitle => 'Gabay ng FDA';

  @override
  String get infoWhoTitle => 'Araw-araw na limitasyon';

  @override
  String get infoWhoSubtitle => 'Gabay ng WHO';

  @override
  String get infoFdaSheetHeading => 'Paano basahin ang nutrition label';

  @override
  String get infoFdaSheetSubtitle => 'Batay sa gabay ng FDA (fda.gov)';

  @override
  String get infoFdaSheetStep1 =>
      'Tingnan ang serving size at bilang ng serving kada pakete. Ang lahat ng nutrient amounts sa label ay batay dito, hindi sa buong pakete.';

  @override
  String get infoFdaSheetStep2 =>
      'Suriin ang calories. 2,000 calories kada araw ang pangkalahatang gabay, pero maaaring iba ang kailangan mo depende sa edad, kasarian, at antas ng aktibidad.';

  @override
  String get infoFdaSheetStep3 =>
      'Gamitin ang % Daily Value (%DV): 5% o mas mababa ay itinuturing na mababa; 20% o mas mataas ay itinuturing na mataas.';

  @override
  String get infoWhoSheetHeading => 'Limitasyon sa nutrients kada araw';

  @override
  String get infoWhoSheetSubtitle =>
      'Batay sa gabay ng WHO, sa 2,000 kcal na diyeta';

  @override
  String get infoWhoSheetLimitSugar => 'Asukal (free sugars)';

  @override
  String get infoWhoSheetLimitSalt => 'Asin (sodium)';

  @override
  String get infoWhoSheetLimitSaturatedFat => 'Saturated fat';

  @override
  String get infoWhoSheetLimitTransFat => 'Trans fat';

  @override
  String get infoWhoSheetLimitSugarValue => '< 50g (10% ng kaloriya)';

  @override
  String get infoWhoSheetLimitSaltValue => '< 2g sodium (< 5g asin)';

  @override
  String get infoWhoSheetLimitSaturatedFatValue => '< 10% ng kaloriya';

  @override
  String get infoWhoSheetLimitTransFatValue => '< 1% ng kaloriya';

  @override
  String get labelIntroTitle => 'Kilalanin ang iyong mga label';

  @override
  String get labelIntroSubtitle =>
      'Sa tulong ng CLARO, mas madaling maunawaan ang mga label at pumili ng mas malusog na opsyon.';

  @override
  String get learnMoreTitle => 'MATUTO PA';

  @override
  String get learnMoreSubtitle =>
      'Mapagkakatiwalaang gabay para mas maintindihan mo ang nutrisyon.';

  @override
  String get fdaCardTitle => 'Paano Basahin ang Nutrition Label';

  @override
  String get fdaCardSource => 'ng FDA';

  @override
  String get whoCardTitle =>
      'Gabay sa Pang-araw-araw na Limitasyon ng Sustansya';

  @override
  String get whoCardSource => 'ng WHO';

  @override
  String get healthConditionsSubtitle =>
      'Impormasyon tungkol sa pagkain at nutrients na may kaugnayan sa GERD at sakit sa bato.';

  @override
  String get kidneyCardTitle => 'Malusog na Pagkain para sa Sakit sa Bato';

  @override
  String get kidneyCardSource => 'ng NIDDK';

  @override
  String get gerdCardTitle => 'Pagkain, Diyeta, at Nutrisyon para sa GERD';

  @override
  String get gerdCardSource => 'ng NIDDK';

  @override
  String get healthGradeTitle => 'Sukat ng kalusugan ng pagkain';

  @override
  String get healthGradeSubtitle =>
      'Kabuuang kalidad ng nutrisyon ng produkto.';

  @override
  String get healthGradeValue0 => 'Pinakamainam – Mataas ang sustansya';

  @override
  String get healthGradeValue1 => 'Rekomendadong pagpipilian';

  @override
  String get healthGradeValue2 => 'Katanggap-tanggap sa katamtamang dami';

  @override
  String get healthGradeValue3 => 'Limitahan ang pagkonsumo';

  @override
  String get healthGradeValue4 => 'Iwasan ang madalas na pagkonsumo';

  @override
  String get ecoGradeTitle => 'Grado ng pagiging maka-kalikasan';

  @override
  String get ecoGradeSubtitle => 'Epekto ng produkto sa planeta.';

  @override
  String get ecoGradeValue0 => 'Napakahusay na epekto sa kapaligiran';

  @override
  String get ecoGradeValue1 => 'Mabuti para sa kapaligiran';

  @override
  String get ecoGradeValue2 => 'Katamtamang epekto sa kapaligiran';

  @override
  String get ecoGradeValue3 => 'Isaalang-alang ang ibang opsyon';

  @override
  String get ecoGradeValue4 => 'Malaking pinsala sa kapaligiran';

  @override
  String get processGradeTitle => 'Antas ng pagpoproseso ng pagkain';

  @override
  String get processGradeSubtitle => 'Gaano kalalim naproseso ang produkto.';

  @override
  String get processGroupFirst => 'Unang grado';

  @override
  String get processGroupFourth => 'Ika-apat na grado';

  @override
  String get processLabel0 => 'Hindi o bahagyang naproseso';

  @override
  String get processLabel1 => 'Naprosesong sangkap sa pagluluto';

  @override
  String get processLabel2 => 'Naprosesong pagkain';

  @override
  String get processLabel3 => 'Ultra-proseso na pagkain';

  @override
  String get bestLabel => 'Pinaka-inirerekomenda';

  @override
  String get worstLabel => 'Pinaka-hindi inirerekomenda';

  @override
  String get scanTabTitle => 'I-scan';

  @override
  String get scanTabSubtitle => 'I-scan ang iyong produkto mula rito.';

  @override
  String get historyTabTitle => 'Kasaysayan';

  @override
  String get historyTabSubtitle =>
      'Makikita mo rito ang iyong history ng pag-scan.';

  @override
  String get welcomeBack => 'Kumusta, ulit!';

  @override
  String get loginToContinue => 'Mag-login upang magpatuloy';

  @override
  String get email => 'Email';

  @override
  String get password => 'Password';

  @override
  String get forgotPassword => 'Nakalimutan ang password?';

  @override
  String get login => 'Mag-login';

  @override
  String get orContinueWith => 'or continue with';

  @override
  String get continueWithGoogle => 'Magpatuloy gamit ang Google';

  @override
  String get dontHaveAccount => 'Wala pang account?';

  @override
  String get signUp => 'Mag-sign up';

  @override
  String get chooseLanguage => 'Piliin ang Lenggwuahe';

  @override
  String get english => 'English';

  @override
  String get tagalog => 'Tagalog';

  @override
  String get passwordRequired => 'Kinakailangan ang password';

  @override
  String get invalidEmailOrPassword => 'Invalid email o password';

  @override
  String get unableSendVerificationCode =>
      'Hindi maipadala ang verification code. Pakisubukang muli.';

  @override
  String get personalInfo => 'Personal na Impormasyon';

  @override
  String get invitePeople => 'Mag-imbita ng Tao';

  @override
  String get preference => 'Preference';

  @override
  String get language => 'Lenggwuahe';

  @override
  String get suggestion => 'Pagsusuri ng App';

  @override
  String get aboutClaro => 'Tungkol sa CLARO';

  @override
  String get privacyPolicy => 'Patakaran sa Privacy';

  @override
  String get termsConditions => 'Mga Tuntunin at Kundisyon';

  @override
  String get agreeToTermsPrefix => 'Sumasang-ayon ako sa ';

  @override
  String get termsConditionsRequiredError =>
      'Kailangan mong sumang-ayon sa Mga Tuntunin at Kundisyon para magpatuloy.';

  @override
  String get closeButton => 'Isara';

  @override
  String get agreeButton => 'Sumasang-ayon';

  @override
  String get onboardingDobError => 'Piliin ang iyong kaarawan.';

  @override
  String get onboardingNameAndDobError =>
      'Ilagay ang iyong pangalan at piliin ang iyong kaarawan.';

  @override
  String get userGuide => 'Gabay sa Gumagamit';

  @override
  String get productName => 'Pangalan ng Produkto';

  @override
  String get category => 'Kategorya';

  @override
  String get logout => 'Logout';

  @override
  String get theme => 'Tema';

  @override
  String get themeSaved => 'Tema na-save';

  @override
  String get themeSaveError => 'Hindi ma-save ang tema';

  @override
  String get themeDefault => 'Default';

  @override
  String get themeDarkMode => 'Dark Mode';

  @override
  String get themeDefaultDescription => 'Karaniwang hitsura ng Claro';

  @override
  String get themeDarkModeDescription =>
      'Madilim na background para sa mga lugar na may mababang ilaw.';

  @override
  String get multiFactorAuthentication => 'Multi-factor authentication';

  @override
  String get voiceAssistant => 'Voice Assistant';

  @override
  String get darkModeSetting => 'Dark Mode';

  @override
  String get mfaSaveError => 'Hindi ma-save ang MFA setting';

  @override
  String get preferenceSaveError => 'Hindi ma-save ang preference';

  @override
  String get preferenceTitle => 'Preference';

  @override
  String get voiceSoundTitle => 'Mga Setting ng Voice Assistant';

  @override
  String get selectLanguage => 'Piliin ang wika';

  @override
  String get speechRate => 'Bilis ng pagsasalita';

  @override
  String get previewAudio => 'I-tap para sa preview ng audio';

  @override
  String get enableVoiceAssistant => 'I-enable ang Voice Assistant';

  @override
  String get vibrationFeedback => 'Vibration feedback';

  @override
  String get vibrateDescription =>
      'Mag-vibrate sa pag-scan, alerto, at pagbabasa';

  @override
  String get textSize => 'Laki ng teksto';

  @override
  String get previewAudioShort => 'Preview ng audio';

  @override
  String get signUpWelcome => 'Welcome!';

  @override
  String get signUpSubtitle => 'Mag-sign up upang makapagsimula';

  @override
  String get alreadyHaveAccount => 'Mayroon ka nang account?';

  @override
  String get accountCreatedTitle => 'Nagawa na ang account';

  @override
  String get accountCreatedMessage => 'Matagumpay na nagawa ang iyong account.';

  @override
  String get okayButton => 'Sige';

  @override
  String get resetPassword => 'I-reset ang password';

  @override
  String get resetPasswordInfo =>
      'Ilagay ang iyong email at magpapadala kami ng link para i-reset ang iyong password.';

  @override
  String get sendResetLink => 'Magpadala ng reset link';

  @override
  String get emailSent => 'Email naipadala';

  @override
  String get checkYourEmail => 'Suriin ang iyong email';

  @override
  String get followLink =>
      'Sundan ang link sa iyong email upang i-reset ang password.';

  @override
  String get backToLogin => 'Bumalik sa pag-login';

  @override
  String get rememberYourPassword => 'Naalala mo na ba ang iyong password?';

  @override
  String get verifyEmail => 'I-verify ang iyong email';

  @override
  String get verificationSentInfo =>
      'May verification code na ipinadala sa iyong email.';

  @override
  String get enterCodeHint => 'Ilagay ang 6-digit na code';

  @override
  String get verify => 'I-verify';

  @override
  String get resendCode => 'Muling ipadala ang code';

  @override
  String resendInSeconds(Object seconds) {
    return 'Muling ipadala sa $seconds s';
  }

  @override
  String get canResendNow => 'Maaari mo nang muling ipadala';

  @override
  String attemptsUsed(Object used) {
    return 'Ginamit na pagtatangka: $used/5';
  }

  @override
  String get tooManyFailedAttempts =>
      'Masyadong maraming nabigong pagtatangka. Mangyaring mag-login muli.';

  @override
  String get unableToResend => 'Hindi ma-resend ang verification code.';

  @override
  String get verificationCodeSent =>
      'May bagong verification code na ipinadala.';

  @override
  String get onboardingNamePrompt => 'Ano ang gusto mong itawag namin sa iyo?';

  @override
  String get onboardingNameHint => 'Pangalan';

  @override
  String get onboardingNameEmpty => 'Pakisulat ang iyong pangalan.';

  @override
  String get onboardingBasicInfoIntro =>
      'Pakilagay ang iyong impormasyon upang magamit ang app';

  @override
  String get onboardingAgeEmpty => 'Pakisulat ang iyong edad.';

  @override
  String get nextButton => 'Susunod';

  @override
  String get onboardingHeadline => 'Malinaw. Lokal. Maaasahan.';

  @override
  String get onboardingSubheadline =>
      'Ang iyong AI na katulong para sa mas malusog na pamimili.';

  @override
  String get featureScan => 'I-scan ang produkto';

  @override
  String get featureNutrition => 'Nutrisyon ng produkto';

  @override
  String get featureHealth => 'Gabay sa kalusugan';

  @override
  String get featureCompare => 'Paghahambing ng produkto';

  @override
  String get getStarted => 'Magsimula';

  @override
  String get getStartedTagline => 'Malinaw. Lokal. Maaasahan.';

  @override
  String get getStartedSubtitle =>
      'Ang iyong AI na katulong para sa mas malusog na pamimili.';

  @override
  String get onboardingInstructions =>
      'Sagutan ang mga sumusunod para sa mas ligtas at mas personalized na rekomendasyon.';

  @override
  String get conditionsQuestion => 'May kondisyon ka ba sa kalusugan?';

  @override
  String get chooseAllThatApply => 'Pumili ng lahat ng naaangkop.';

  @override
  String get profileChangeNote =>
      'Maaari mo itong baguhin sa iyong profile settings.';

  @override
  String get allergensQuestion => 'May mga allergen bang dapat iwasan?';

  @override
  String get safetyPriorityTitle => 'Prayoridad namin ang iyong kaligtasan';

  @override
  String get safetyPriorityMessage =>
      'Gagamitin namin ang impormasyong ito upang magbigay ng health insights at mas ligtas na rekomendasyon.';

  @override
  String get suggestionIntro => 'Gusto naming marinig ang iyong feedback.';

  @override
  String get rateYourExperience => 'I-rate ang iyong karanasan';

  @override
  String get shareImprovement => 'Ibahagi kung ano ang maaari naming i-improve';

  @override
  String get submit => 'Ipadala';

  @override
  String get sending => 'Ipinapadala...';

  @override
  String get suggestionSentTitle => 'Naipadalang feedback!';

  @override
  String get suggestionSentBody =>
      'Salamat! Matagumpay na naipadala ang iyong feedback.';

  @override
  String get backLabel => 'Bumalik';

  @override
  String get needSignInToSubmit =>
      'Mangyaring mag-sign in bago magpadala ng suhestiyon.';

  @override
  String get submitError => 'May error sa pagpapadala';

  @override
  String get aboutClaroHeading => 'Alamin ang tungkol sa amin!';

  @override
  String get aboutClaroDescription =>
      'Ang CLARO ay isang AI-powered mobile app na tumutulong sa mga mamimili ng groceries na maunawaan ang impormasyon sa nutrisyon ng lokal na de-latang pagkain. Sa pamamagitan ng pag-scan ng produkto, makikita ng mga user ang pinasimpleng nutrition summaries, health advisories, allergen warnings, product comparisons, at accessibility features tulad ng voice assistance para makapili ng mas matalino at mas malusog na desisyon sa pagbili.';

  @override
  String get aboutDevelopers => 'Tungkol sa mga developer';

  @override
  String get profileUpdateSuccess => 'Na-update ang profile';

  @override
  String get profileUpdateError => 'Hindi ma-save ang mga update';

  @override
  String get editName => 'I-edit ang pangalan';

  @override
  String get editAge => 'I-edit ang edad';

  @override
  String get cancel => 'Kanselahin';

  @override
  String get save => 'I-save';

  @override
  String get ageLabel => 'Edad';

  @override
  String get none => 'Wala';

  @override
  String get healthConditions => 'Kondisyon sa Kalusugan';

  @override
  String get allergensLabel => 'Allergens';

  @override
  String get accountSettings => 'Account Settings';

  @override
  String get changePassword => 'Baguhin ang password';

  @override
  String get currentPassword => 'Kasalukuyang Password';

  @override
  String get newPassword => 'Bagong Password';

  @override
  String get confirmPassword => 'I-type muli ang bagong Password';

  @override
  String get passwordRequirements =>
      'Ang iyong password ay dapat nasa hindi babababang anim na characters na may kombinasyon ng numero, letra, at ibang special characters (!@#%)';

  @override
  String get passwordChanged => 'Password successfully changed!';

  @override
  String get errorCurrentPassword =>
      'Pakisulat ang iyong kasalukuyang password';

  @override
  String get errorNewPassword => 'Pakisulat ang iyong bagong password';

  @override
  String get errorConfirmPassword => 'Pakikonfirman ang iyong bagong password';

  @override
  String get errorPasswordsNotMatch => 'Ang mga password ay hindi tumutugma';

  @override
  String get errorPasswordTooShort =>
      'Ang password ay dapat na hindi bababa sa 8 characters';

  @override
  String get errorPasswordUppercase =>
      'Ang password ay dapat maglaman ng kahit isang uppercase letter';

  @override
  String get errorPasswordLowercase =>
      'Ang password ay dapat maglaman ng kahit isang lowercase letter';

  @override
  String get errorPasswordNumber =>
      'Ang password ay dapat maglaman ng kahit isang numero';

  @override
  String get errorPasswordSpecial =>
      'Ang password ay dapat maglaman ng kahit isang special character';

  @override
  String get errorNotAuthenticated => 'User not authenticated';

  @override
  String get errorChangingPassword => 'Error changing password';

  @override
  String get unexpectedError => 'An unexpected error occurred';

  @override
  String get emailRequired => 'Kinakailangan ang email';

  @override
  String get invalidEmail => 'Mangyaring maglagay ng valid na email address';

  @override
  String get validEmailHint =>
      'Isang valid na email address (hal. pangalan@halimbawa.com)';

  @override
  String get selectAllergen => 'Pumili ng Allergen';

  @override
  String get conditionDiabetes => 'Diabetes';

  @override
  String get conditionHypertension => 'Alta-presyon';

  @override
  String get conditionHeartCondition => 'Sakit sa puso';

  @override
  String get conditionGerd => 'GERD (Gastroesophageal Reflux Disease)';

  @override
  String get conditionKidneyDisease => 'Sakit sa bato';

  @override
  String get gerdWarningTitle => 'Babala sa GERD';

  @override
  String get gerdWarningIntro =>
      'Ang produktong ito ay naglalaman ng mga sangkap na maaaring mag-trigger o magpalala ng sintomas ng GERD. Ang mga sangkap na nasa ibaba ay kadalasang nauugnay sa acid reflux.';

  @override
  String get gerdNoTriggersFound =>
      'Walang karaniwang GERD trigger na natukoy mula sa available na impormasyon ng produkto.';

  @override
  String get gerdInsufficientData =>
      'Hindi sapat ang impormasyon sa sangkap o nutrition ng produktong ito para masuri ang mga karaniwang GERD trigger.';

  @override
  String get gerdDisclaimer =>
      'Pangkalahatang impormasyon lamang ito, hindi diagnosis o medical advice. Kung nakakaranas ka ng sintomas, kumonsulta sa iyong doktor.';

  @override
  String get gerdExpertAdvice =>
      'Mainam na kumonsulta muna sa isang expert bago uminom ng produktong ito.';

  @override
  String get gerdTriggerTomatoAcidic => 'Tomato / maasim na sangkap';

  @override
  String get gerdTriggerSpicy => 'Maanghang na sangkap';

  @override
  String get gerdTriggerCaffeine => 'Caffeine';

  @override
  String get gerdTriggerChocolate => 'Chocolate / cacao';

  @override
  String get gerdTriggerHighFat => 'Mataas na taba (fat)';

  @override
  String get kidneyWarningTitle => 'Babala sa Sakit sa Bato';

  @override
  String get kidneyWarningIntro =>
      'Ang mga nutrients na ito ay maaaring may kaugnayan sa kalusugan ng bato. Nagkakaiba-iba ang pangangailangan sa diyeta ng bawat tao depende sa kanilang kondisyon sa bato.';

  @override
  String get kidneyDisclaimer =>
      'Pangkalahatang impormasyon lamang ito, hindi diagnosis o medical advice. Kumonsulta sa iyong healthcare provider para sa personalized na gabay sa diyeta.';

  @override
  String get kidneyExpertAdvice =>
      'Pinakamainam na kumonsulta sa isang dalubhasa upang matukoy ang tamang dami ng mga nabanggit na nutrient ng produkto para sa iyo.';

  @override
  String get kidneyNoNutrientsFound =>
      'Walang nutrients na may kaugnayan sa bato ang natukoy mula sa available na impormasyon ng produkto.';

  @override
  String get kidneyNutrientSodium => 'Sodium';

  @override
  String get kidneyNutrientPotassium => 'Potassium';

  @override
  String get kidneyNutrientProtein => 'Protein';

  @override
  String get kidneyNutrientPhosphorus => 'Phosphorus';

  @override
  String get combinedGerdKidneyWarningTitle => 'Babala sa GERD at Sakit sa Bato';

  @override
  String get combinedGerdKidneyIntro =>
      'Ang produktong ito ay naglalaman ng mga sangkap o nutrients na maaaring may kaugnayan sa parehong GERD at kalusugan ng bato. Nagkakaiba-iba ang pangangailangan sa diyeta ng bawat tao depende sa kanilang mga kondisyon.';

  @override
  String get conditionLowVision => 'Mababang Paningin';

  @override
  String get conditionNone => 'Wala';

  @override
  String get allergenFish => 'Isda';

  @override
  String get allergenMilk => 'Gatas';

  @override
  String get allergenEggs => 'Itlog';

  @override
  String get allergenSoy => 'Soya';

  @override
  String get allergenWheat => 'Trigo';

  @override
  String get allergenShellfish => 'Lamang-Dagat';

  @override
  String get allergenPeanuts => 'Mani';

  @override
  String get filterConditionTitle => 'Filter ranking by condition';

  @override
  String get conditionOverall => 'Overall (all conditions)';

  @override
  String get filterProductTypeTitle => 'Uri ng Produkto';

  @override
  String get filterFlavorTitle => 'Lasa';

  @override
  String get spicyLabel => 'Maanghang';

  @override
  String get nonSpicyLabel => 'Hindi Maanghang';

  @override
  String get apply => 'I-apply';

  @override
  String get ratePrompt => 'Mangyaring pumili ng rating sa pagitan ng 1 at 5.';

  @override
  String get suggestionEmpty =>
      'Mangyaring ilagay ang iyong suhestiyon bago ipadala.';

  @override
  String get suggestionTooLong =>
      'Ang suhestiyon ay dapat 500 characters o mas mababa pa.';

  @override
  String get suggestionHint => 'Isulat ang iyong mungkahi dito...';

  @override
  String get clearAllTitle => 'Burahin ang Lahat?';

  @override
  String get clearAllConfirm =>
      'Mabubura ang lahat ng kasaysayan ng iyong mga scan. Hindi ito maibabalik.';

  @override
  String get clearAllFavoritesConfirm =>
      'Aalisin ang lahat ng naka-save na paborito. Hindi ito maibabalik.';

  @override
  String get clear => 'Burahin';

  @override
  String get clearAll => 'Burahin Lahat';

  @override
  String get searchHint => 'Maghanap';

  @override
  String get tabAll => 'Lahat';

  @override
  String get tabFavorites => 'Paborito';

  @override
  String get tabCompare => 'Kumpara';

  @override
  String get tabReports => 'Mga Ulat';

  @override
  String get emptyFavorites =>
      'Wala pang mga paboritong produkto. I-tap ang ❤️ upang mag-save.';

  @override
  String get emptyComparisons => 'Wala pang mga pag-uugnayan ng produkto.';

  @override
  String noSearchResults(String query) {
    return 'Walang resulta para sa \"$query\"';
  }

  @override
  String get emptyHistory =>
      'Wala pang kasaysayan ng scan. I-scan ang isang produkto upang magsimula!';

  @override
  String get historyToday => 'Ngayon';

  @override
  String get historyYesterday => 'Kahapon';

  @override
  String get historyLastWeek => 'Nakaraang Linggo';

  @override
  String get historyLastMonth => 'Nakaraang Buwan';

  @override
  String get resultsTitle => 'Resulta';

  @override
  String get rankedBySuitability => 'Naka-rank batay sa suitability';

  @override
  String get profileFeatureSoon => 'Parating na ang mga feature ng Profile!';

  @override
  String get fdaExpiredWarning =>
      'BABALA: Ang produktong ito ay may EXPIRED na FDA registration. Maaaring hindi ito ligtas.';

  @override
  String get fdaUnverifiedWarning =>
      'Ang produktong ito ay hindi pa nabeberipika ng FDA Philippines.';

  @override
  String get ageRequirementBadge => '3+ yrs old';

  @override
  String get safeToConsume => 'LIGTAS I-KONSUMO';

  @override
  String get safeToConsumeSubtitle =>
      'Pinakamainam kainin sa katamtamang dami dahil mas mataas sa taba at calories.';

  @override
  String get reminderLabel => 'Paalala';

  @override
  String get diabetesSafeReminder =>
      'Angkop para sa mga may diabetes, ngunit ang madalas na pagkonsumo ay maaaring hindi mainam para sa mga nagkokontrol ng kolesterol o calorie intake.';

  @override
  String containsAllergens(String list) {
    return 'Naglalaman ng $list';
  }

  @override
  String get personalHealthWarningTitle => '🩺 Babala Batay sa Iyong Kalusugan';

  @override
  String get servingRecommendation =>
      '½–¾ ng lata (90–135g) sa bawat meal, maaaring kainin 2–3 beses kada linggo.';

  @override
  String get moreDetailsLink => 'Higit pang detalye';

  @override
  String get totalNutritionTitle => 'Kabuuang Nutrisyon';

  @override
  String get nutritionDataUnavailable =>
      'Hindi available ang datos ng nutrisyon';

  @override
  String get nutriCalories => 'Calories';

  @override
  String get nutriCarbs => 'Carbs';

  @override
  String get nutriSodium => 'Sodium';

  @override
  String get nutriSugar => 'Sugar';

  @override
  String get nutriProtein => 'Protina';

  @override
  String get nutriTotalFat => 'Total Fat';

  @override
  String get nutriSatFat => 'Sat. Fat';

  @override
  String get nutriTransFat => 'Trans Fat';

  @override
  String get nutriFiber => 'Fiber';

  @override
  String get nutriPotassium => 'Potassium';

  @override
  String get nutriCalcium => 'Calcium';

  @override
  String get nutriIron => 'Iron';

  @override
  String get scoresTitle => 'Grado';

  @override
  String get scoreNutrition => 'Nutrisyon';

  @override
  String get scoreNutritionDesc =>
      'Magandang pinagkukunan ng protina ngunit mas mataas sa taba at calories.';

  @override
  String get scoreEnvironment => 'Kalikasan';

  @override
  String get scoreEnvironmentDesc => 'Katamtamang epekto sa kalikasan.';

  @override
  String get scoreProcess => 'Proseso';

  @override
  String get scoreProcessDesc =>
      'Naprosesong pagkain na may medyo simpleng sangkap.';

  @override
  String get compareButton => 'Ihambing';

  @override
  String get similarProductsTitle => 'Pagraranggo ng Produkto';

  @override
  String productCount(int count) {
    return '$count produkto';
  }

  @override
  String get noProductsFound => 'Walang nahanap';

  @override
  String get noSearchMatchDesc =>
      'Walang mga produktong tumutugma sa iyong paghahanap.';

  @override
  String get seeMore => 'Tingnan Pa';

  @override
  String get scanGuideText => 'Itapat ang camera sa produkto';

  @override
  String get scanGuideTextPrefix => 'Itapat ang camera sa ';

  @override
  String get scanGuideTextEmphasis => 'produkto';

  @override
  String get scanGuideTextSuffix => '';

  @override
  String get productCapturedBadge => 'Nakuha na ang Produkto!';

  @override
  String get tapToScanHint => 'I-tap kahit saan para i-scan';

  @override
  String get productNotRecognizedTitle => 'Hindi Kilalang Produkto';

  @override
  String get productNotRecognizedDesc =>
      'Hindi nakilala ang produkto. Gusto mo bang ipadala ito para sa pagsusuri?';

  @override
  String get tryAgainButton => 'Subukan Muli';

  @override
  String get submitLabel => 'Ipadala';

  @override
  String get submitSkuHeader => 'IPADALA ANG HINDI KILALANG SKU';

  @override
  String get trainModelHeadline => 'Tulungan Kaming Sanayin ang Model';

  @override
  String get trainModelSubtitle =>
      'Kung hindi na-detect ang produkto, i-upload ang photo at impormasyon nito. Ginagamit ito para ma-improve ang aming engine.';

  @override
  String get imageCaptureSuccess => 'Matagumpay na nakuha ang mock image!';

  @override
  String get imageRequiredError =>
      'Mangyaring kumuha muna ng larawan ng label.';

  @override
  String get submissionReceivedTitle => 'Natanggap na ang Ipinadala';

  @override
  String get submissionReceivedDesc =>
      'Salamat! Susuriin ng aming AI team ang label at ia-update ang database sa loob ng 24 oras.';

  @override
  String get returnToScanner => 'Bumalik sa Scanner';

  @override
  String get labelImageAttached => 'May nakalakip na larawan';

  @override
  String get tapToReplace => 'I-tap para palitan ang photo';

  @override
  String get captureProductLabel => 'Kumuha ng Larawan ng Label';

  @override
  String get ensureReadableNote =>
      'Siguraduhing nababasa ang text at nutrition facts';

  @override
  String get productNameLabel => 'Pangalan ng Produkto / Deskripsyon';

  @override
  String get productNameEmpty => 'Pakilagay ang pangalan ng produkto';

  @override
  String get brandNameLabel => 'Brand (hal. Century, Ligo, Lucky Me)';

  @override
  String get brandNameEmpty => 'Pakilagay ang brand';

  @override
  String get productVariantLabel => 'Variant (hal. Hot & Spicy, Sweet & Sour)';

  @override
  String get productVariantEmpty => 'Pakilagay ang variant';

  @override
  String get productCategoryLabel => 'Kategorya';

  @override
  String get ingredientsListLabel => 'Listahan ng Sangkap (Opsiyonal)';

  @override
  String get submitTrainingButton => 'IPADALA PARA SA TRAINING';

  @override
  String get bestLabelShort => 'Best';

  @override
  String get worstLabelShort => 'Worst';

  @override
  String get analysisBasisTitle => 'Pagsusuri sa Kalusugan';

  @override
  String analysisBasisSubtitle(String servingSize) {
    return 'Batay sa Healthy Diet Fact Sheet ng WHO, bawat 1 serving ($servingSize)';
  }

  @override
  String get bpSodiumLabel => 'Presyon ng dugo - Sodium';

  @override
  String get diabetesSugarsLabel => 'Diabetes - Total sugars';

  @override
  String get heartSatFatLabel => 'Sakit sa puso - Saturated fats';

  @override
  String get bpSodiumShortLabel => 'Sodium';

  @override
  String get kidneySodiumLabel => 'Sakit sa Bato - Sodium';

  @override
  String get ckdBpSodiumLabel => 'CKD at Presyon ng Dugo - Sodium';

  @override
  String get diabetesSugarsShortLabel => 'Total sugars';

  @override
  String get heartSatFatShortLabel => 'Saturated fats';

  @override
  String get dailySuffix => 'sanggunian';

  @override
  String get ofWhoLimit => 'ng sanggunian ng WHO';

  @override
  String get ofWhoFreeSugarReference => 'ng sanggunian ng WHO para sa asukal';

  @override
  String get allergenDetectedBadge => 'Allergen Detected';

  @override
  String get allergenWarningNote =>
      'Awtomatikong nagdudulot ng babala kung saved allergen mo ito.';

  @override
  String get suitableLegend => 'mababa ≤5%';

  @override
  String get moderateLegend => 'katamtaman 6-20%';

  @override
  String get cautionLegend => 'mataas >20%';

  @override
  String get levelLow => 'mababa';

  @override
  String get levelMedium => 'katamtaman';

  @override
  String get levelHigh => 'mataas';

  @override
  String get howToUnderstandTitle => 'Paano unawain:';

  @override
  String get legendSuitableDesc => 'Maliit na bahagi ng sanggunian.';

  @override
  String get legendModerateDesc => 'Kapansin-pansing bahagi ng sanggunian.';

  @override
  String get legendCautionDesc => 'Malaking bahagi ng sanggunian.';

  @override
  String get howClaroCalculatesTitle =>
      'Paano Kinakalkula ng CLARO ang Iyong Health Guide';

  @override
  String get howClaroCalculatesIntro =>
      'Nagtatakda ang WHO ng malusog na sanggunian kada araw para sa bawat nutrient. Inikukumpara ng CLARO ang halaga ng produktong ito bawat serving sa sanggunian na iyon at ginagawang porsyento. Ginagamit ng CLARO ang porsyentong iyon — hindi ang WHO — para markahan ang produkto bilang Suitable, Moderate, o Caution.';

  @override
  String get howClaroReferencePrefix => 'Sumasangguni kami sa ';

  @override
  String get howClaroReferenceLinkLabel =>
      'Healthy Diet ng World Health Organization';

  @override
  String get calculationFormulaLabel => 'Ang formula';

  @override
  String get calculationFormula =>
      'Halaga ng produkto kada serving ÷ Recommended Daily Intake × 100 = % ng Recommended Daily Intake';

  @override
  String get howClaroExampleTitle => 'Halimbawa mula sa produktong ito';

  @override
  String get howClaroExampleUnavailable =>
      'Walang available na nutrition facts para sa produktong ito, kaya hindi namin ito maipapakita bilang halimbawa.';

  @override
  String get productAmountPerServingLabel => 'Halaga ng produkto';

  @override
  String get whoReferenceLabel => 'Recommended Daily Intake';

  @override
  String get whoFreeSugarReferenceLabel => 'Recommended Daily Intake para sa free sugars';

  @override
  String get howClaroClassificationTitle => 'Paano ito ini-klasipika ng CLARO';

  @override
  String get forMoreDetails => 'Higit pang detalye';

  @override
  String get moreDetailsScreenTitle => 'Higit pang Detalye';

  @override
  String get ingredientsTitle => 'Mga Sangkap';

  @override
  String containsAllergenPrefix(String allergen) {
    return 'Naglalaman ng $allergen - allergen';
  }

  @override
  String get storageTitle => 'Paraan ng Pag-iimbak';

  @override
  String get storageTipCool => 'Itago sa malamig at tuyong lugar bago buksan.';

  @override
  String get storageTipRefrigerate =>
      'Ilipat sa sealed container at i-refrigerate kapag bukas na.';

  @override
  String get storageTipConsume =>
      'Ubusin sa loob ng 2-3 araw pagkatapos buksan.';

  @override
  String get notFoundTitle => 'Walang nahanap na produkto';

  @override
  String get notFoundBody => 'Hindi namin matukoy ang produktong ito.';

  @override
  String get notFoundHint =>
      'Maaari kang mag-scan muli o i-report ang produktong ito.';

  @override
  String get scanAgainButton => 'Mag-scan muli';

  @override
  String get reportProductButton => 'I-report ang produkto';

  @override
  String get reportTitle => 'Iulat ang hindi matukoy produkto';

  @override
  String get reportSubtitle =>
      'Maari mo kaming tulungan sa pagbigay ng detalye tungkol sa produktong ito.';

  @override
  String get reportProductPhoto => 'Litrato ng Produkto';

  @override
  String get reportFrontPhoto => 'Litrato sa Harap';

  @override
  String get reportBackPhoto => 'Litrato sa Likod (Nutrition Label)';

  @override
  String get reportBackPhotoHint =>
      'Kumuha ng malinaw na litrato ng nutrition facts at listahan ng sangkap sa likod ng produkto.';

  @override
  String get reportAddBackPhoto => 'Magdagdag ng Litrato';

  @override
  String get reportBackPhotoRequired =>
      'Mangyaring magdagdag ng litrato ng likod na label bago mag-submit.';

  @override
  String get reportChangePhoto => 'Baguhin ang Litrato';

  @override
  String get reportProductName => 'Pangalan ng Produkto';

  @override
  String get reportAdditionalBackPhotos =>
      'Karagdagang Litrato sa Likod (Opsyonal)';

  @override
  String get reportAdditionalBackPhotosHint =>
      'Magdagdag ng higit pang litrato ng likod na label kung kinakailangan (sangkap, nutrition facts, atbp.)';

  @override
  String get reportAddAnotherBackPhoto =>
      'Magdagdag ng Isa Pang Litrato sa Likod';

  @override
  String get reportProductNameHint =>
      'Pakisabi ang brand, pangalan, at lasa (hal. Purefoods Corned Beef).';

  @override
  String get reportProductNameFieldHint => 'Ilagay ang pangalan ng produkto';

  @override
  String get reportProductDescription => 'Deskripsyon ng Produkto';

  @override
  String get reportEditButton => 'I-Edit';

  @override
  String get reportInfoNote =>
      'Ang iyong report ay makakatulong magdagdag ng maraming produkto at mas magbigay ng mabuting impormasyon para sa lahat.';

  @override
  String get reportSubmitButton => 'I-submit';

  @override
  String get reportSuccessTitle => 'Naipadala na ang report!';

  @override
  String get reportSuccessBody =>
      'Maraming Salamat! Matagumpay na naipadala ang iyong ulat.';

  @override
  String get reportGoHome => 'Bumalik sa Home';

  @override
  String get dateOfBirth => 'Petsa ng Kapanganakan';

  @override
  String get january => 'Enero';

  @override
  String get february => 'Pebrero';

  @override
  String get march => 'Marso';

  @override
  String get april => 'Abril';

  @override
  String get may => 'Mayo';

  @override
  String get june => 'Hunyo';

  @override
  String get july => 'Hulyo';

  @override
  String get august => 'Agosto';

  @override
  String get september => 'Setyembre';

  @override
  String get october => 'Oktubre';

  @override
  String get november => 'Nobyembre';

  @override
  String get december => 'Disyembre';

  @override
  String get invalidDateOfBirth =>
      'Mangyaring pumili ng wastong petsa ng kapanganakan';

  @override
  String get under18Error =>
      'Dapat kang nasa edad na 18 pataas para magamit ang app na ito';

  @override
  String get enterDigitCode => 'Ilagay ang 6-digit na code';

  @override
  String get pleaseEnterProductName =>
      'Mangyaring ilagay ang pangalan ng produkto';

  @override
  String get reportButtonToast => 'Maling produkto? I-report ito dito';

  @override
  String get addProductButton => 'Magdagdag ng Produkto';

  @override
  String get selectProductsToAddTitle => 'Pumili ng Produktong Idaragdag';

  @override
  String get alreadyInRankingLabel => 'Nasa iyong ranggo na';

  @override
  String get noNewProductsDetected =>
      'Walang bagong produktong natukoy. Subukang mag-scan muli.';

  @override
  String productsAddedToRanking(int count) {
    return '$count produkto ang naidagdag sa iyong ranggo';
  }

  @override
  String get selectAtLeastOneProduct =>
      'Pumili ng kahit isang produkto para idagdag';

  @override
  String get noInternetTitle => 'Walang Koneksyon sa Internet';

  @override
  String get noInternetNutritionMessage =>
      'Kumonekta sa mobile data o Wi-Fi para sa buong datos ng nutrisyon.';

  @override
  String get noInternetActionMessage =>
      'Mangyaring kumonekta sa mobile data o Wi-Fi para isagawa ang aksyong ito.';

  @override
  String get noInternetReportMessage =>
      'Mangyaring kumonekta sa mobile data o Wi-Fi para maipadala ang report na ito.';

  @override
  String get gotIt => 'Naintindihan';

  @override
  String get offlineBasicRecognitionBanner =>
      'Offline mode: Pangunahing pagkilala lamang. Kumonekta muli para sa buong nutrisyon.';

  @override
  String get noInternetHealthProfileMessage =>
      'Mangyaring kumonekta sa mobile data o Wi-Fi para i-update ang iyong health conditions at allergens.';

  @override
  String get noInternetReviewMessage =>
      'Mangyaring kumonekta sa mobile data o Wi-Fi para maipadala ang iyong review.';

  @override
  String get reportQueuedTitle => 'Na-save ang Report Offline';

  @override
  String get reportQueuedMessage =>
      'Ang iyong report ay na-save offline at awtomatikong maipapadala kapag nakakonekta ka na muli sa internet.';

  @override
  String get noInternetVoiceMessage =>
      'Mangyaring kumonekta sa mobile data o Wi-Fi para gamitin ang Voice Assistant.';

  @override
  String get groupTab => 'Grupo';

  @override
  String get noGroupYet => 'Wala pang grupo';

  @override
  String get groupEmptyStateTitle =>
      'I-evaluate ang mga produkto para sa buong sambahayan mo';

  @override
  String get groupEmptyStateSubtitle =>
      'Gumawa ng grupo para makita ang health evaluation ng bawat miyembro ng pamilya, kaibigan, o kasama sa bahay tuwing mag-scan ka ng produkto.';

  @override
  String get joinGroupButton => 'Sumali';

  @override
  String get createGroupButton => 'Gumawa';

  @override
  String get nameYourGroup => 'Pangalanan ang iyong grupo';

  @override
  String get groupNameHint => 'hal. Ang Aking Pamilya';

  @override
  String get defaultGroupName => 'Aking Health Group';

  @override
  String get groupOwnerLabel => 'Ikaw ang may-ari ng grupong ito';

  @override
  String get groupMemberLabel => 'Ikaw ay isang miyembro';

  @override
  String get groupDetailsMembers => 'Mga Miyembro';

  @override
  String get groupDetailsNoMembers => 'Wala pang miyembro.';

  @override
  String get memberStatusLinked => 'Naka-link';

  @override
  String get memberStatusManaged => 'Pinamamahalaan';

  @override
  String get removeFromGroupTooltip => 'Alisin sa grupo';

  @override
  String get deleteMemberTooltip => 'Burahin ang miyembro';

  @override
  String get removeFromGroupTitle => 'Alisin sa grupo?';

  @override
  String get deleteMemberTitle => 'Burahin ang miyembrong ito?';

  @override
  String get removeFromGroupMessage =>
      'Aalisin sila sa grupo. Hindi maaapektuhan ang kanilang sariling health data.';

  @override
  String get deleteMemberMessage =>
      'Permanenteng mabubura ang entry at health data ng miyembrong ito.';

  @override
  String get removeButton => 'Alisin';

  @override
  String get addMemberButton => 'Magdagdag ng Miyembro';

  @override
  String get addMemberChooserTitle => 'Magdagdag ng miyembro';

  @override
  String get inviteSomeoneTitle => 'Mag-imbita ng tao';

  @override
  String get inviteSomeoneSubtitle =>
      'I-install nila ang app at pamamahalaan ang sarili nilang profile';

  @override
  String get addManuallyTitle => 'Idagdag nang manu-mano';

  @override
  String get addManuallySubtitle => 'Para sa taong walang sariling account';

  @override
  String get memberNameHint => 'Pangalan ng miyembro';

  @override
  String get memberNameEmptyError => 'Ilagay ang pangalan ng miyembrong ito';

  @override
  String memberAddedSuccess(Object name) {
    return 'Naidagdag si $name sa iyong grupo';
  }

  @override
  String memberAddedHealthDataFailed(Object name) {
    return 'Naidagdag si $name, pero hindi na-save ang health info. I-edit sila para subukan ulit.';
  }

  @override
  String get viewOnlyHealthProfileNote =>
      'Makikita mo ang health profile ng miyembrong ito, pero sila lang ang maaaring mag-edit nito.';

  @override
  String get noHealthProfileYet => 'Wala pang naidagdag na health info';

  @override
  String get editHealthProfile => 'I-edit';

  @override
  String get deleteGroupButton => 'Burahin ang Grupo';

  @override
  String get deleteGroupDisabledHint =>
      'Alisin muna ang lahat ng miyembro bago mabura ang grupong ito.';

  @override
  String get deleteGroupConfirmTitle => 'Burahin ang grupong ito?';

  @override
  String get deleteGroupConfirmMessage => 'Hindi na ito maaaring bawiin.';

  @override
  String get deleteGroupSuccess => 'Nabura ang grupo';

  @override
  String get deleteAllGroupsButton => 'Burahin Lahat';

  @override
  String get deleteAllGroupsConfirmTitle => 'Burahin lahat ng grupo?';

  @override
  String get deleteAllGroupsConfirmMessage =>
      'Aalisin ka bilang miyembro sa lahat ng grupo sa listahang ito. Ang mga grupong pagmamay-ari mo na may ibang miyembro ay hindi mabubura hangga\'t hindi tinatanggal ang mga miyembrong iyon. Hindi na ito mababawi.';

  @override
  String get deleteAllGroupsSuccess => 'Nabura lahat ng grupo';

  @override
  String deleteAllGroupsPartialSuccess(int count) {
    return '$count na grupo ang hindi natanggal. Kailangang tanggalin muna ang ibang miyembro sa mga grupong pagmamay-ari mo.';
  }


  @override
  String get joinGroupDialogTitle => 'Sumali sa Grupo';

  @override
  String get joinGroupDialogSubtitle =>
      'Ilagay ang code na ibinahagi sa iyo para sumali sa kanilang health group.';

  @override
  String get inviteCodeHint => 'hal. AB3D9F2KH';

  @override
  String get invalidCodeError => 'Maglagay ng wastong 9-karakter na code';

  @override
  String get codeDidNotWorkError =>
      'Hindi gumana ang code na iyon. Tingnan at subukan ulit.';

  @override
  String get joinGroupSubmit => 'Sumali sa Grupo';

  @override
  String get joinViaQr => 'Sumali gamit ang QR';

  @override
  String get scanQrTitle => 'I-scan ang QR ng Imbitasyon';

  @override
  String get scanQrInstruction =>
      'Itutok ang iyong camera sa QR code na ibinahagi sa iyo.';

  @override
  String get qrCameraPermissionDenied =>
      'Kailangan ng pahintulot sa camera para i-scan ang QR code.';

  @override
  String get inviteMemberTitle => 'Mag-imbita ng Miyembro';

  @override
  String get inviteMemberInstructions =>
      'Ibahagi ang code o QR na ito sa taong gusto mong idagdag. Mag-e-expire ito sa loob ng 48 oras at minsan lang magagamit.';

  @override
  String get copyCode => 'Kopyahin ang code';

  @override
  String get codeCopied => 'Nakopya ang code';

  @override
  String get revokeAndRegenerate => 'Bawiin at Gumawa ng Bagong Code';

  @override
  String get somethingWentWrong => 'May nangyaring mali. Pakisubukan ulit.';
}