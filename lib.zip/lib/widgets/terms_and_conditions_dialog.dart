import 'package:flutter/material.dart';
import '../generated/l10n/app_localizations.dart';

/// One block of body content within a [_TermsSection]. Either a plain
/// paragraph ([paragraph] set) or a bulleted list ([bullets] set).
class _TermsBlock {
  final String? paragraph;
  final List<String>? bullets;

  const _TermsBlock.paragraph(this.paragraph) : bullets = null;
  const _TermsBlock.bullets(this.bullets) : paragraph = null;
}

class _TermsSection {
  final String title;
  final List<_TermsBlock> blocks;

  const _TermsSection(this.title, this.blocks);
}

/// Full text of CLARO's Terms & Conditions, reproduced verbatim from the
/// source document and broken into sections/bullets purely for on-screen
/// readability. No content is omitted or truncated.
const _termsLastUpdated = 'Last Updated: September 21, 2026';
const _termsVersion = 'Terms Version 1.0';
const _termsIntro =
    'These Terms and Conditions ("Terms") govern your access to and use of '
    'the CLARO mobile application and its related services. By creating an '
    'account or using CLARO, you agree to these Terms. If you do not agree '
    'with these Terms, please do not use the application.';

final List<_TermsSection> _termsSections = [
  _TermsSection('1. About CLARO', [
    const _TermsBlock.paragraph(
      'CLARO is a food product recognition and nutritional information '
      'application designed to help users identify selected food products '
      'and understand information such as:',
    ),
    const _TermsBlock.bullets([
      'Product information',
      'Nutritional values',
      'FDA registration information',
      'Nutri-Score',
      'NOVA classification',
      'Allergen information',
      'Health-related advisories',
      'Product comparisons and rankings',
      'Group health evaluations and shared profile viewing',
    ]),
    const _TermsBlock.paragraph(
      "The application may also provide personalized recommendations "
      "based on information voluntarily entered into the user's health "
      "profile or group health profiles.",
    ),
  ]),
  _TermsSection('2. Eligibility and Account', [
    const _TermsBlock.paragraph(
      'To access features requiring authentication, you must create or '
      'access a CLARO account using one of the authentication methods '
      'supported by the application.',
    ),
    const _TermsBlock.paragraph('You are responsible for:'),
    const _TermsBlock.bullets([
      'Providing accurate information when required',
      'Maintaining the security of your account',
      'Keeping your authentication credentials confidential',
      'Not sharing your account with unauthorized individuals',
      'Immediately reporting suspected unauthorized access',
    ]),
    const _TermsBlock.paragraph(
      'CLARO may restrict or terminate access when an account is used in '
      'violation of these Terms or in a manner that threatens the security '
      'or integrity of the system.',
    ),
  ]),
  _TermsSection('3. Health Profile and Health Groups', [
    const _TermsBlock.paragraph(
      'CLARO allows users to provide information about their health '
      'conditions (such as Diabetes, Hypertension, Heart Condition, GERD, '
      'and Kidney Disease) and food allergies.',
    ),
    const _TermsBlock.paragraph(
      'This information is used to personalize product advisories, '
      'warnings, and individual or group product evaluations.',
    ),
    const _TermsBlock.paragraph(
      'Users may create or join Health Groups where group members can view '
      'each other\'s health conditions to consider member health when '
      'evaluating products.',
    ),
    const _TermsBlock.paragraph(
      'Health profile management and permissions within groups strictly follow these rules:',
    ),
    const _TermsBlock.bullets([
      'Only registered account holders can manage and update their own health profile.',
      'Group members can view invited members\' health profiles, but cannot modify or edit them.',
      'Group owners can manage health conditions for manually added members created within their group.',
      'Only group owners have authority to remove a member from a group.',
      'Only group owners can delete a group, provided the group has no remaining members beside the group owner.',
    ]),
    const _TermsBlock.paragraph(
      'You are responsible for ensuring that the information in your '
      'health profile or manually added member profiles is accurate and up to date.',
    ),
  ]),
  _TermsSection('4. Health and Medical Disclaimer', [
    const _TermsBlock.paragraph(
      'CLARO is an informational and educational tool and is not a '
      'substitute for professional medical advice, diagnosis, or '
      'treatment.',
    ),
    const _TermsBlock.paragraph(
      'Health advisories, warnings, classifications, and recommendations '
      'generated by CLARO are intended to help users understand '
      'nutritional and product-related information.',
    ),
    const _TermsBlock.paragraph('They should not be interpreted as:'),
    const _TermsBlock.bullets([
      'A medical diagnosis',
      'A prescription',
      'A treatment plan',
      'Professional dietary advice',
      'A substitute for consultation with a physician, registered '
          'dietitian, nutritionist, or other qualified healthcare '
          'professional',
    ]),
    const _TermsBlock.paragraph(
      'Users with medical conditions, food allergies, dietary '
      'restrictions, or other health concerns should consult an '
      'appropriate healthcare professional before making significant '
      'dietary or health-related decisions.',
    ),
    const _TermsBlock.paragraph(
      'In case of an allergic reaction or medical emergency, seek '
      'appropriate professional medical assistance immediately.',
    ),
  ]),
  _TermsSection('5. Accuracy of Information', [
    const _TermsBlock.paragraph(
      'CLARO attempts to provide useful and relevant product and '
      'nutritional information. However, information may originate from '
      'databases, publicly available sources, product labels, OCR '
      'extraction, or other reference sources.',
    ),
    const _TermsBlock.paragraph(
      'Accordingly, CLARO does not guarantee that all information will '
      'always be:',
    ),
    const _TermsBlock.bullets([
      'Accurate',
      'Complete',
      'Current',
      'Error-free',
      'Available',
      "Suitable for a particular individual's circumstances",
    ]),
    const _TermsBlock.paragraph(
      "Users should verify important nutritional, allergen, and "
      "regulatory information using the product's official packaging, "
      "labeling, or appropriate authoritative sources.",
    ),
  ]),
  _TermsSection('6. Product Recognition', [
    const _TermsBlock.paragraph(
      'CLARO uses image recognition technology to identify supported food '
      'products.',
    ),
    const _TermsBlock.paragraph(
      'Recognition results may occasionally be incorrect because of:',
    ),
    const _TermsBlock.bullets([
      'Image quality',
      'Lighting conditions',
      'Camera positioning',
      'Product packaging changes',
      'Similar product designs',
      'Occlusion or obstruction',
      'Model limitations',
    ]),
    const _TermsBlock.paragraph(
      'Users should verify the identified product before relying on the '
      'information presented by the application.',
    ),
  ]),
  _TermsSection('7. Product Comparison and Ranking', [
    const _TermsBlock.paragraph(
      'CLARO may provide product comparisons and rankings based on '
      "nutritional information and, where applicable, the user's health "
      'profile.',
    ),
    const _TermsBlock.paragraph(
      'These rankings are intended to assist users in comparing products.',
    ),
    const _TermsBlock.paragraph(
      'A higher-ranked product does not necessarily mean that it is '
      'medically or nutritionally appropriate for every individual.',
    ),
    const _TermsBlock.paragraph(
      'Users should consider their personal circumstances and consult '
      'qualified professionals when necessary.',
    ),
  ]),
  _TermsSection('8. Nutri-Score and NOVA Classification', [
    const _TermsBlock.paragraph(
      'CLARO may display Nutri-Score and NOVA classifications to help '
      'users understand nutritional quality and processing levels.',
    ),
    const _TermsBlock.paragraph(
      'These classifications are provided for informational purposes.',
    ),
    const _TermsBlock.paragraph(
      "They should not be interpreted as a complete assessment of a "
      "product's overall healthfulness or suitability for a particular "
      "individual.",
    ),
  ]),
  _TermsSection('9. FDA and Regulatory Information', [
    const _TermsBlock.paragraph(
      'CLARO may display Philippine FDA-related information, including '
      'product registration numbers and validity dates, as reference '
      'information.',
    ),
    const _TermsBlock.paragraph(
      'The application does not independently issue, modify, or grant FDA '
      'registration.',
    ),
    const _TermsBlock.paragraph(
      'Regulatory information displayed by CLARO should be verified '
      'through appropriate official Philippine FDA sources when '
      'regulatory confirmation is required.',
    ),
  ]),
  _TermsSection('10. Voice Assistant', [
    const _TermsBlock.paragraph(
      'CLARO may provide voice-assisted navigation and interaction.',
    ),
    const _TermsBlock.paragraph(
      'Users are responsible for ensuring that microphone permissions are '
      'appropriately configured on their device.',
    ),
    const _TermsBlock.paragraph(
      'Voice recognition may not always accurately understand spoken '
      'commands because of factors such as:',
    ),
    const _TermsBlock.bullets([
      'Background noise',
      'Pronunciation',
      'Accent',
      'Microphone quality',
      'Internet connectivity',
      'Language selection',
    ]),
    const _TermsBlock.paragraph(
      'Users should not rely exclusively on voice commands for critical '
      'actions.',
    ),
  ]),
  _TermsSection('11. User-Submitted Product Reports', [
    const _TermsBlock.paragraph(
      'Users may submit reports for products that CLARO does not '
      'recognize.',
    ),
    const _TermsBlock.paragraph(
      'Users agree that submitted information should be:',
    ),
    const _TermsBlock.bullets([
      'Accurate to the best of their knowledge',
      'Relevant to the product being reported',
      'Free from intentionally misleading information',
      "Appropriate for the application's intended purpose",
    ]),
    const _TermsBlock.paragraph(
      'CLARO administrators may review, validate, reject, or otherwise '
      'process submitted reports.',
    ),
    const _TermsBlock.paragraph(
      "Submitting a report does not guarantee that the product will be "
      "added to the application's database.",
    ),
  ]),
  _TermsSection('12. Prohibited Use', [
    const _TermsBlock.paragraph('You agree not to use CLARO to:'),
    const _TermsBlock.bullets([
      'Provide intentionally false or misleading information',
      'Submit fraudulent product reports',
      "Attempt to access another user's account",
      "Attempt to access another user's health information",
      'Circumvent authentication or security controls',
      "Interfere with the application's operation",
      'Abuse or overload application services',
      'Reverse engineer or attempt to compromise security mechanisms',
      'Use the application for unlawful purposes',
      "Use another person's personal information without authorization",
    ]),
    const _TermsBlock.paragraph(
      "CLARO reserves the right to restrict access where misuse threatens "
      "the application's users, data, or infrastructure.",
    ),
  ]),
  _TermsSection('13. Intellectual Property', [
    const _TermsBlock.paragraph(
      'The CLARO application, including its software, interface, design, '
      'branding, logos, original written content, and other original '
      'materials, is owned by or licensed to the CLARO development team '
      'and is protected by applicable intellectual property laws.',
    ),
    const _TermsBlock.paragraph(
      "Unless expressly permitted, users may not reproduce, redistribute, "
      "modify, or commercially exploit CLARO's original materials without "
      "appropriate authorization.",
    ),
    const _TermsBlock.paragraph(
      'Third-party names, trademarks, databases, and services remain the '
      'property of their respective owners.',
    ),
  ]),
  _TermsSection('14. Third-Party Services', [
    const _TermsBlock.paragraph(
      'CLARO may rely on third-party services such as:',
    ),
    const _TermsBlock.bullets([
      'Firebase Authentication',
      'Firebase Firestore',
      'Google OAuth',
      'Nutritional and regulatory reference databases',
      'AI services used for advisory explanations',
    ]),
    const _TermsBlock.paragraph(
      "The availability and operation of these third-party services may "
      "affect CLARO's functionality.",
    ),
    const _TermsBlock.paragraph(
      'Third-party services may have their own terms, privacy policies, '
      'and technical limitations.',
    ),
  ]),
  _TermsSection('15. Availability of the Application', [
    const _TermsBlock.paragraph(
      'We aim to keep CLARO available and functional; however, '
      'uninterrupted availability cannot be guaranteed.',
    ),
    const _TermsBlock.paragraph(
      'The application may temporarily become unavailable because of:',
    ),
    const _TermsBlock.bullets([
      'Maintenance',
      'Software updates',
      'Server or cloud-service interruptions',
      'Internet connectivity issues',
      'Third-party service outages',
      'Security incidents',
      'Technical failures',
    ]),
    const _TermsBlock.paragraph(
      'CLARO may modify, suspend, or discontinue certain features when '
      'necessary.',
    ),
  ]),
  _TermsSection('16. Account Deletion', [
    const _TermsBlock.paragraph(
      "Users may request deletion of their CLARO account through the "
      "application's account deletion feature.",
    ),
    const _TermsBlock.paragraph(
      'Once successfully processed, the account and associated user '
      "information will be deleted in accordance with the application's "
      'Privacy Policy and applicable requirements.',
    ),
    const _TermsBlock.paragraph(
      'Account deletion may result in permanent loss of access to '
      'information associated with the account.',
    ),
  ]),
  _TermsSection('17. Disclaimer of Warranties', [
    const _TermsBlock.paragraph(
      'To the extent permitted by applicable law, CLARO is provided on an '
      '"as is" and "as available" basis.',
    ),
    const _TermsBlock.paragraph('We do not guarantee that:'),
    const _TermsBlock.bullets([
      'The application will always be available',
      'Product recognition will always be accurate',
      'Nutritional information will always be complete or current',
      'Health recommendations will be appropriate for every user',
      'Third-party services will always be available',
      'The application will be free from all errors or interruptions',
    ]),
  ]),
  _TermsSection('18. Limitation of Liability', [
    const _TermsBlock.paragraph(
      'To the extent permitted by applicable law, CLARO and its '
      'development team shall not be responsible for losses or damages '
      'resulting from reliance on information provided by the '
      'application, including nutritional information, product '
      'classifications, product rankings, health advisories, or product '
      'recognition results.',
    ),
    const _TermsBlock.paragraph(
      'Users remain responsible for verifying information and making '
      'their own decisions regarding food consumption and health.',
    ),
    const _TermsBlock.paragraph(
      'Nothing in these Terms is intended to exclude or limit rights or '
      'obligations that cannot legally be excluded or limited under '
      'applicable law.',
    ),
  ]),
  _TermsSection('19. Privacy', [
    const _TermsBlock.paragraph(
      'Your use of CLARO is also governed by our Privacy Policy, which '
      'explains how personal information is collected, used, stored, '
      'protected, and managed.',
    ),
    const _TermsBlock.paragraph(
      'By using CLARO, you acknowledge that you have reviewed the Privacy '
      'Policy.',
    ),
  ]),
  _TermsSection('20. Changes to These Terms', [
    const _TermsBlock.paragraph(
      'We may update these Terms when necessary to reflect changes to the '
      'application, its features, or applicable requirements.',
    ),
    const _TermsBlock.paragraph(
      'Updated Terms will be posted on this page with a revised Last '
      'Updated date.',
    ),
    const _TermsBlock.paragraph(
      'Your continued use of CLARO after changes are posted constitutes '
      'acceptance of the updated Terms, to the extent permitted by '
      'applicable law.',
    ),
  ]),
  _TermsSection('21. Governing Law', [
    const _TermsBlock.paragraph(
      'These Terms shall be interpreted and governed in accordance with '
      'the applicable laws of the Republic of the Philippines, including '
      'relevant provisions applicable to the use of digital services and '
      'data protection.',
    ),
  ]),
];

/// Body + header + footer of the Terms & Conditions dialog, extracted
/// into its own StatefulWidget (rather than a plain closure inside
/// showDialog's builder) specifically so it can own a [ScrollController]
/// with a proper [dispose] and drive the mandatory variant's "Agree"
/// button off real scroll position.
///
/// NEW: when [requireAgreement] is true (the blocking, post-Google-auth
/// gate), the "Agree" button now starts disabled (grayed out,
/// unclickable) and only becomes enabled once the user has scrolled the
/// body to (or very near) the bottom -- they can no longer tap "Agree"
/// without ever having scrolled past the header. The informational
/// variant (opened from the Sign Up screen's "Terms and Conditions"
/// link) has no footer button at all, so this gating doesn't apply to it.
class _TermsDialogContent extends StatefulWidget {
  final bool requireAgreement;
  final double width;
  final double height;

  const _TermsDialogContent({
    required this.requireAgreement,
    required this.width,
    required this.height,
  });

  @override
  State<_TermsDialogContent> createState() => _TermsDialogContentState();
}

class _TermsDialogContentState extends State<_TermsDialogContent> {
  final _scrollController = ScrollController();

  // Only the mandatory variant gates anything on this -- the
  // informational variant has no footer button to enable/disable, so it
  // starts (and stays) true for it.
  late bool _reachedEnd = !widget.requireAgreement;

  @override
  void initState() {
    super.initState();
    if (widget.requireAgreement) {
      _scrollController.addListener(_handleScroll);
      // If the terms happen to fit on screen without overflowing (very
      // tall dialog, very short content, a big display, etc.) there is
      // nothing to scroll through -- don't leave the user stuck unable
      // to ever satisfy a scroll event that will never fire.
      WidgetsBinding.instance.addPostFrameCallback(
        (_) => _checkInitialOverflow(),
      );
    }
  }

  void _checkInitialOverflow() {
    if (!mounted || _reachedEnd || !_scrollController.hasClients) return;
    if (_scrollController.position.maxScrollExtent <= 0) {
      setState(() => _reachedEnd = true);
    }
  }

  void _handleScroll() {
    if (_reachedEnd || !_scrollController.hasClients) return;
    // Small tolerance so the user doesn't have to land on the exact last
    // pixel of scroll extent for this to register as "reached the end".
    const tolerance = 24.0;
    final position = _scrollController.position;
    if (position.pixels >= position.maxScrollExtent - tolerance) {
      setState(() => _reachedEnd = true);
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_handleScroll);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final loc = AppLocalizations.of(context)!;
    final tl = Localizations.localeOf(context).languageCode == 'tl';

    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: Column(
        children: [
          // Fixed header: title (+ close button, informational
          // variant only) never scrolls away.
          Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 12, 14),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: theme.dividerColor)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    loc.termsConditions,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: colorScheme.onSurface,
                    ),
                  ),
                ),
                // The close (X) button only exists in the
                // informational variant. When agreement is required,
                // there must be no way to dismiss the dialog other
                // than tapping "Agree" -- see class doc comment above.
                if (!widget.requireAgreement)
                  IconButton(
                    icon: Icon(Icons.close, color: colorScheme.onSurfaceVariant),
                    tooltip: loc.closeButton,
                    onPressed: () => Navigator.of(context).pop(false),
                  ),
              ],
            ),
          ),
          // Scrollable body: only this part moves. Drives _reachedEnd
          // for the mandatory variant via _scrollController above.
          Expanded(
            child: Scrollbar(
              controller: _scrollController,
              child: SingleChildScrollView(
                controller: _scrollController,
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _termsLastUpdated,
                      style: TextStyle(
                        fontSize: 12,
                        color: colorScheme.onSurfaceVariant,
                      ),
                    ),
                    Text(
                      _termsVersion,
                      style: TextStyle(
                        fontSize: 12,
                        color: colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      _termsIntro,
                      style: TextStyle(
                        fontSize: 14,
                        height: 1.5,
                        color: colorScheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: 20),
                    for (final section in _termsSections) ...[
                      Text(
                        section.title,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: colorScheme.primary,
                        ),
                      ),
                      const SizedBox(height: 8),
                      for (final block in section.blocks) ...[
                        if (block.paragraph != null)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Text(
                              block.paragraph!,
                              style: TextStyle(
                                fontSize: 14,
                                height: 1.5,
                                color: colorScheme.onSurface,
                              ),
                            ),
                          ),
                        if (block.bullets != null)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: block.bullets!.map((b) {
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 4),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(top: 6, right: 8),
                                        child: Container(
                                          width: 4,
                                          height: 4,
                                          decoration: BoxDecoration(
                                            color: colorScheme.onSurfaceVariant,
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          b,
                                          style: TextStyle(
                                            fontSize: 14,
                                            height: 1.5,
                                            color: colorScheme.onSurface,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                      ],
                      const SizedBox(height: 12),
                    ],
                  ],
                ),
              ),
            ),
          ),
          // Fixed footer: the single, mandatory "Agree" action.
          // Informational variant has no footer at all -- reading the
          // terms never required an explicit acknowledgement.
          if (widget.requireAgreement)
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
              decoration: BoxDecoration(
                border: Border(top: BorderSide(color: theme.dividerColor)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Only shown while the button is still disabled --
                  // tells the user why they can't proceed yet, rather
                  // than leaving a grayed-out button unexplained.
                  if (!_reachedEnd)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Text(
                        tl
                            ? 'Mag-scroll hanggang sa dulo upang magpatuloy.'
                            : 'Scroll to the end to continue.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 12,
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: colorScheme.primary,
                        disabledBackgroundColor:
                            colorScheme.onSurfaceVariant.withValues(alpha: 0.35),
                        disabledForegroundColor:
                            colorScheme.onPrimary.withValues(alpha: 0.7),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      // Grayed out and unclickable until _reachedEnd
                      // flips true -- the only way out of a mandatory
                      // dialog remains this single "Agree" action, but
                      // now it can't fire before the user has actually
                      // scrolled through the terms.
                      onPressed:
                          _reachedEnd ? () => Navigator.of(context).pop(true) : null,
                      child: Text(
                        loc.agreeButton,
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// Shows the Terms & Conditions in a modal card with a fixed width/height,
/// a header that stays put, and only the body text scrolling underneath
/// it. Follows the app's existing theme (light/dark) via [Theme.of], so it
/// renders correctly regardless of which mode is active in the surrounding
/// context.
///
/// By default (`requireAgreement: false`) this is the informational
/// variant used from the Sign Up form's "Terms & Conditions" link: it has
/// a close (X) button in the header, no footer button, can be dismissed by
/// tapping the barrier, and always resolves to `false` since agreeing
/// isn't required just to read the terms.
///
/// When `requireAgreement: true` (used for the post-Google-auth gate) the
/// dialog becomes a blocking acceptance step instead of a reader: there is
/// no close (X) button, no Skip/Cancel/Decline button, the barrier cannot
/// be tapped away, and the hardware/system back gesture is suppressed.
/// The ONLY way to leave the dialog is the single "Agree" button in the
/// footer, which resolves the returned future to `true` -- and that
/// button is now disabled (grayed out, unclickable) until the user has
/// scrolled the body to the end (see [_TermsDialogContentState]).
/// Everything else (dimensions, theming, header title, body
/// content/scrolling) is shared with the informational variant so the two
/// never visually diverge.
///
/// Returns `true` if the user tapped "Agree" (only possible when
/// `requireAgreement` is true AND they've scrolled to the end), `false`
/// otherwise (dismissed, closed, or the informational variant was used).
Future<bool> showTermsAndConditionsDialog(
  BuildContext context, {
  bool requireAgreement = false,
}) async {
  final result = await showDialog<bool>(
    context: context,
    barrierDismissible: !requireAgreement,
    builder: (dialogContext) {
      final theme = Theme.of(dialogContext);
      final screenSize = MediaQuery.of(dialogContext).size;

      // Fixed card dimensions regardless of how much text there is --
      // only the content inside scrolls.
      final cardWidth = screenSize.width * 0.9;
      final cardHeight = (screenSize.height * 0.8).clamp(400.0, 640.0);

      final dialogCard = Dialog(
        backgroundColor: theme.cardColor,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: _TermsDialogContent(
          requireAgreement: requireAgreement,
          width: cardWidth,
          height: cardHeight,
        ),
      );

      if (!requireAgreement) return dialogCard;

      // Belt-and-suspenders: barrierDismissible is already false above,
      // but PopScope also blocks the Android hardware/gesture back
      // action, which is a separate dismissal path from the barrier.
      // Without this, a user could back-gesture out of a "required"
      // dialog without ever tapping "Agree".
      return PopScope(
        canPop: false,
        child: dialogCard,
      );
    },
  );
  return result ?? false;
}