import 'package:flutter/material.dart';
import '../generated/l10n/app_localizations.dart';
import '../services/auth_service.dart';
import '../services/home_tab_controller.dart';
import '../services/haptic_service.dart';
import '../services/locale_service.dart';
import '../widgets/avatar_picker.dart';
import '../widgets/date_of_birth_picker.dart';
import '../widgets/onboarding_page_dots.dart';
import 'home_screen.dart';

/// NOTE ON LANGUAGE: this screen's user-facing text now follows the
/// app-wide selected language (see LoginScreen's header comment for
/// background on why this changed for the auth/onboarding screens).
///
/// NOTE ON FLOW: this screen used to be a 3-page PageView (Basic Info →
/// Get Started → Health Profile) shown after login. "Get Started" has
/// since moved to its own standalone screen (GetStartedScreen) before
/// language selection and Login/Sign Up -- so this is now a 2-page flow:
/// Basic Info → Health Profile.
///
/// IMPORTANT: the keys in _conditions / _allergens (e.g. 'Diabetes',
/// 'Alta-presyon', 'Isda') are NOT just UI labels -- they are the exact
/// values written to Firestore in saveOnboardingData() and read back by
/// the backend's health-advisory pipeline (see
/// firestore_label_mappings.dart, referenced from product_detail_screen
/// .dart). Renaming these keys would silently break condition/allergen
/// matching for any user who already completed onboarding under the old
/// keys. So those internal keys are left untouched; only the on-screen
/// *display* text is localized, via the _conditionDisplay*/
/// _allergenDisplay* maps below, which are purely cosmetic and never
/// written anywhere.
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key, this.returnTo, this.returnBuilder});

  final String? returnTo;
  final WidgetBuilder? returnBuilder;

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  final _nameController = TextEditingController();
  String? _nameError;
  final _authService = AuthService();
  int _currentPage = 0;
  bool _isLoading = false;

  // Date of birth selected via the wheel picker on the Basic Info page.
  // DateOfBirthPicker only ever reports a value here when it represents a
  // valid, non-future date corresponding to someone at least 18 years old
  // (it reports null otherwise), so this being non-null is sufficient to
  // treat the date of birth as "selected and valid".
  DateTime? _dateOfBirth;
  String? _dobError;

  // Avatar asset path chosen on the Basic Info page (required).
  String? _avatar;
  bool _avatarError = false;

  // Internal storage keys -- DO NOT translate these, see class doc above.
  final Map<String, bool> _conditions = {
    'Diabetes': false,
    'Alta-presyon': false,
    'Sakit sa puso': false,
    'GERD': false,
    'Sakit sa bato': false,
    'Mababang Paningin': false,
    'Wala': false,
  };

  final Map<String, bool> _allergens = {
    'Isda': false,
    'Gatas': false,
    'Itlog': false,
    'Soya': false,
    'Trigo': false,
    'Lamang-Dagat': false,
    'Mani': false,
  };

  final Map<String, IconData> _conditionIcons = {
    'Diabetes': Icons.monitor_heart_outlined,
    'Alta-presyon': Icons.favorite_outline,
    'Sakit sa puso': Icons.favorite_border,
    'GERD': Icons.local_fire_department_outlined,
    'Sakit sa bato': Icons.health_and_safety_outlined,
    'Mababang Paningin': Icons.visibility_outlined,
    'Wala': Icons.block,
  };

  final Map<String, IconData> _allergenIcons = {
    'Isda': Icons.set_meal_outlined,
    'Gatas': Icons.local_drink_outlined,
    'Itlog': Icons.egg_alt_outlined,
    'Soya': Icons.grass_outlined,
    'Trigo': Icons.grain,
    'Lamang-Dagat': Icons.restaurant_outlined,
    'Mani': Icons.eco_outlined,
  };

  // Cosmetic-only display labels for the internal keys above, built from
  // AppLocalizations so they follow the selected language -- the keys
  // themselves keep going to Firestore unchanged (see class doc above).
  Map<String, String> _conditionDisplay(AppLocalizations loc) => {
    'Diabetes': loc.conditionDiabetes,
    'Alta-presyon': loc.conditionHypertension,
    'Sakit sa puso': loc.conditionHeartCondition,
    'GERD': loc.conditionGerd,
    'Sakit sa bato': loc.conditionKidneyDisease,
    'Mababang Paningin': loc.conditionLowVision,
    'Wala': loc.conditionNone,
  };

  Map<String, String> _allergenDisplay(AppLocalizations loc) => {
    'Isda': loc.allergenFish,
    'Gatas': loc.allergenMilk,
    'Itlog': loc.allergenEggs,
    'Soya': loc.allergenSoy,
    'Trigo': loc.allergenWheat,
    'Lamang-Dagat': loc.allergenShellfish,
    'Mani': loc.allergenPeanuts,
  };

  @override
  void initState() {
    super.initState();
    // Listen for language changes to refresh the UI with localized labels
    LocaleService.localeNotifier.addListener(_onLocaleChanged);
  }

  void _onLocaleChanged() {
    if (mounted) {
      setState(() {}); // Force rebuild to update localized labels
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _pageController.dispose();
    LocaleService.localeNotifier.removeListener(_onLocaleChanged);
    super.dispose();
  }

  void _previousPage() {
    HapticService().vibrate();
    FocusScope.of(context).unfocus();
    _pageController.previousPage(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  Future<void> _nextPage() async {
    HapticService().vibrate();
    final loc = AppLocalizations.of(context)!;
    if (_currentPage < 1) {
      // Validate name and date of birth together so the user gets a single,
      // clear message covering whichever field(s) are incomplete, rather
      // than being blocked repeatedly one field at a time.
      final nameEmpty = _nameController.text.trim().isEmpty;
      final dobMissing = _dateOfBirth == null;
      final avatarMissing = _avatar == null;

      if (nameEmpty || dobMissing || avatarMissing) {
        final tl = Localizations.localeOf(context).languageCode == 'tl';
        setState(() {
          _nameError = nameEmpty ? loc.onboardingNameEmpty : null;
          _dobError = dobMissing ? loc.onboardingDobError : null;
          _avatarError = avatarMissing;
        });
        HapticService().vibrate();
        // Name/DOB keep their existing messages; the avatar message is
        // only shown alone or when it's the only thing missing.
        final String message;
        if (avatarMissing && !nameEmpty && !dobMissing) {
          message = tl ? 'Pumili ng avatar.' : 'Please choose an avatar.';
        } else if (nameEmpty && dobMissing) {
          message = loc.onboardingNameAndDobError;
        } else if (nameEmpty) {
          message = loc.onboardingNameEmpty;
        } else if (dobMissing) {
          message = loc.onboardingDobError;
        } else {
          message = tl ? 'Pumili ng avatar.' : 'Please choose an avatar.';
        }
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(message)));
        return;
      } else {
        setState(() {
          _nameError = null;
          _dobError = null;
          _avatarError = false;
        });
      }

      // Dismiss keyboard/focus before moving to the next page -- Basic
      // Info has text fields but Health Profile doesn't, so carrying
      // focus over serves no purpose and risks the same kind of overflow
      // issue fixed on the Login → Get Started transition.
      FocusScope.of(context).unfocus();
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      // Validate name
      if (_nameController.text.trim().isEmpty) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(loc.onboardingNameEmpty)));
        return;
      }

      setState(() => _isLoading = true);

      final selectedConditions = _conditions.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

      final selectedAllergens = _allergens.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

      try {
        await _authService.saveOnboardingData(
          name: _nameController.text.trim(),
          dateOfBirth: _dateOfBirth,
          avatar: _avatar,
          conditions: selectedConditions,
          allergens: selectedAllergens,
        );

        if (!mounted) return;
        HomeTabController.switchToTab(0);
        FocusScope.of(context).unfocus();
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (ctx) =>
                widget.returnBuilder?.call(ctx) ?? const HomeScreen(),
          ),
        );
      } catch (e) {
        debugPrint('Onboarding data save failed: $e');
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Failed to save your profile. Please check your connection and try again.',
            ),
            duration: const Duration(seconds: 4),
          ),
        );
      }

      setState(() => _isLoading = false);
    }
  }

  void _toggleCondition(String key) {
    HapticService().vibrate();
    setState(() {
      if (key == 'Wala') {
        _conditions.forEach((k, v) => _conditions[k] = false);
        _conditions['Wala'] = true;
      } else {
        _conditions['Wala'] = false;
        _conditions[key] = !_conditions[key]!;
      }
    });
  }

  void _toggleAllergen(String key) {
    HapticService().vibrate();
    setState(() {
      _allergens[key] = !_allergens[key]!;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Force Light Mode for Onboarding Screen
    return Theme(
      data: ThemeData(
        brightness: Brightness.light,
        primaryColor: const Color(0xFF8B1A1A),
        scaffoldBackgroundColor: const Color(0xFFF5F0EE),
        colorScheme: ColorScheme.light(
          primary: const Color(0xFF8B1A1A),
          onPrimary: Colors.white,
          secondary: const Color(0xFFD32F2F),
          onSecondary: Colors.white,
          surface: Colors.white,
          onSurface: const Color(0xFF1A1A1A),
          error: Colors.redAccent,
          onError: Colors.white,
          surfaceContainerHighest: const Color(0xFFE0E0E0),
          outlineVariant: const Color(0xFFBDBDBD),
          onSurfaceVariant: const Color(0xFF757575),
        ),
        useMaterial3: true,
      ),
      child: Builder(
        builder: (context) {
          final theme = Theme.of(context);
          final loc = AppLocalizations.of(context)!;
          return PopScope(
            canPop: _currentPage == 0,
            onPopInvokedWithResult: (didPop, result) {
              if (didPop) return;
              if (_currentPage > 0) {
                _previousPage();
              }
            },
            child: Scaffold(
              backgroundColor: theme.scaffoldBackgroundColor,
              body: SafeArea(
                child: PageView(
                  controller: _pageController,
                  physics: _currentPage == 0
                      ? const NeverScrollableScrollPhysics()
                      : const PageScrollPhysics(),
                  onPageChanged: (i) => setState(() => _currentPage = i),
                  children: [_buildPage1(theme, loc), _buildPage2(theme, loc)],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildPage1(ThemeData theme, AppLocalizations loc) {
    final colorScheme = theme.colorScheme;
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
      child: Column(
        children: [
          const SizedBox(height: 40),
          _buildLogo(theme),
          const SizedBox(height: 32),
          Text(
            loc.onboardingBasicInfoIntro,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              color: colorScheme.onSurface,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 24),
          Semantics(
            hint: _nameError != null ? 'Error: $_nameError' : null,
            child: TextField(
              controller: _nameController,
              onChanged: (val) {
                if (_nameError != null && val.trim().isNotEmpty) {
                  setState(() {
                    _nameError = null;
                  });
                }
                // Trigger rebuild to update button enabled state
                setState(() {});
              },
              style: TextStyle(color: colorScheme.onSurface),
              decoration: InputDecoration(
                hintText: loc.onboardingNameHint,
                hintStyle: TextStyle(
                  color: colorScheme.onSurfaceVariant,
                  fontSize: 14,
                ),
                prefixIcon: Icon(
                  Icons.person_outline,
                  color: colorScheme.onSurfaceVariant,
                  size: 20,
                ),
                errorText: _nameError,
                errorMaxLines: 2,
                contentPadding: const EdgeInsets.symmetric(
                  vertical: 14,
                  horizontal: 12,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: colorScheme.outlineVariant),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: colorScheme.primary),
                ),
                errorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: colorScheme.error),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: colorScheme.error, width: 1.5),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Semantics(
            hint: _dobError != null ? 'Error: $_dobError' : null,
            child: DateOfBirthPicker(
              initialDate: _dateOfBirth,
              onDateChanged: (date) {
                setState(() {
                  _dateOfBirth = date;
                  if (date != null && _dobError != null) {
                    _dobError = null;
                  }
                });
              },
            ),
          ),
          if (_dobError != null) ...[
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.only(left: 4),
              child: Row(
                children: [
                  Icon(Icons.error_outline, size: 14, color: colorScheme.error),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      _dobError!,
                      style: TextStyle(color: colorScheme.error, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 24),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Avatar',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: colorScheme.onSurface,
              ),
            ),
          ),
          const SizedBox(height: 12),
          AvatarPicker(
            selected: _avatar,
            allowClear:
                false, // required: one avatar is always kept once chosen
            onChanged: (a) => setState(() {
              _avatar = a;
              if (a != null) _avatarError = false;
            }),
          ),
          if (_avatarError) ...[
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(left: 4),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.error_outline,
                      size: 14,
                      color: colorScheme.error,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      Localizations.localeOf(context).languageCode == 'tl'
                          ? 'Pumili ng avatar.'
                          : 'Please choose an avatar.',
                      style: TextStyle(color: colorScheme.error, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 32),
          _buildButton(
            loc.nextButton,
            _nextPage,
            theme,
            checkValidation: true,
            isFormValid: isBasicInfoValid,
          ),
          const SizedBox(height: 20),
          // Page 1 of 2
          const Center(child: OnboardingPageDots.onLight(activeIndex: 0)),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildPage2(ThemeData theme, AppLocalizations loc) {
    final colorScheme = theme.colorScheme;
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: IconButton(
                  icon: const Icon(Icons.arrow_back_ios_new_rounded),
                  color: colorScheme.primary,
                  onPressed: _previousPage,
                  tooltip: 'Back',
                ),
              ),
              _buildLogo(theme),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            loc.onboardingInstructions,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color: colorScheme.onSurface,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 20),
          _buildSelectionCard(
            icon: Icons.favorite_border,
            title: loc.conditionsQuestion,
            subtitle: loc.chooseAllThatApply,
            note: loc.profileChangeNote,
            noteIcon: Icons.info_outline,
            child: _buildConditionsGrid(theme, loc),
          ),
          const SizedBox(height: 16),
          _buildSelectionCard(
            icon: Icons.warning_amber_rounded,
            iconColor: const Color(0xFFB45309),
            title: loc.allergensQuestion,
            subtitle: loc.chooseAllThatApply,
            child: _buildAllergensGrid(theme, loc),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: colorScheme.surfaceContainerHighest.withAlpha(80),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: colorScheme.outlineVariant),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.shield_outlined,
                  color: colorScheme.primary,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        loc.safetyPriorityTitle,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                          color: colorScheme.primary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        loc.safetyPriorityMessage,
                        style: TextStyle(
                          fontSize: 12,
                          color: colorScheme.onSurface,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _buildButton(
            loc.getStarted,
            _nextPage,
            theme,
            checkValidation: true,
            isFormValid: _isFormValid,
          ),
          const SizedBox(height: 12),
          // Page 2 of 2
          const Center(child: OnboardingPageDots.onLight(activeIndex: 1)),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildConditionsGrid(ThemeData theme, AppLocalizations loc) {
    final display = _conditionDisplay(loc);
    final keys = _conditions.keys.toList();
    return _buildToggleWrap(
      keys.map((key) {
        final selected = _conditions[key]!;
        return GestureDetector(
          onTap: () {
            HapticService().vibrate();
            _toggleCondition(key);
          },
          child: _buildToggleItem(
            label: display[key] ?? key,
            selected: selected,
            icon: _conditionIcons[key],
            theme: theme,
          ),
        );
      }).toList(),
    );
  }

  Widget _buildAllergensGrid(ThemeData theme, AppLocalizations loc) {
    final display = _allergenDisplay(loc);
    final keys = _allergens.keys.toList();
    return _buildToggleWrap(
      keys.map((key) {
        final selected = _allergens[key]!;
        return GestureDetector(
          onTap: () {
            HapticService().vibrate();
            _toggleAllergen(key);
          },
          child: _buildToggleItem(
            label: display[key] ?? key,
            selected: selected,
            icon: _allergenIcons[key],
            theme: theme,
          ),
        );
      }).toList(),
    );
  }

  // BUG FIX: this used to be a GridView.count(..., childAspectRatio: 0.85),
  // which forces every option into the exact same fixed-height box no
  // matter how much content (icon + up to 2 lines of label text) that
  // option actually needs. Options with short one-line labels fit fine,
  // but ones whose label needs the full 2 lines -- especially on
  // narrower phones, or with the app's own adjustable text-size setting
  // turned up -- didn't have enough room, so their content overflowed
  // that fixed box ("RenderFlex overflowed by X pixels").
  //
  // A Wrap of fixed-WIDTH (not fixed-height) boxes keeps the same
  // 4-per-row layout, but each option's box now grows to fit its own
  // content -- every option is properly wrapped in its own box, with no
  // shared hardcoded height left to overflow.
  Widget _buildToggleWrap(List<Widget> items) {
    const crossAxisCount = 4;
    const spacing = 8.0;
    return LayoutBuilder(
      builder: (context, constraints) {
        final itemWidth =
            (constraints.maxWidth - spacing * (crossAxisCount - 1)) /
            crossAxisCount;
        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: items
              .map((item) => SizedBox(width: itemWidth, child: item))
              .toList(),
        );
      },
    );
  }

  Widget _buildToggleItem({
    required String label,
    required bool selected,
    IconData? icon,
    required ThemeData theme,
  }) {
    final colorScheme = theme.colorScheme;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      height: 96,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
      decoration: BoxDecoration(
        color: selected ? colorScheme.primary.withAlpha(24) : theme.cardColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: selected ? colorScheme.primary : colorScheme.outlineVariant,
          width: selected ? 1.5 : 1,
        ),
      ),
      child: Stack(
        children: [
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 32,
                  width: 32,
                  child: Icon(
                    icon,
                    size: 28,
                    color: selected
                        ? colorScheme.primary
                        : colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 4),
                // Allow text wrapping for longer labels like "Mababang Paningin"
                // while keeping consistent font size across all options
                // softWrap ensures words wrap at word boundaries, not character boundaries
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Text(
                    label,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    softWrap: true,
                    style: TextStyle(
                      fontSize: 10,
                      color: selected
                          ? colorScheme.primary
                          : colorScheme.onSurface,
                      fontWeight: selected
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (selected)
            Positioned(
              top: 4,
              right: 4,
              child: Container(
                width: 16,
                height: 16,
                decoration: BoxDecoration(
                  color: colorScheme.primary,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.check, size: 10, color: Colors.white),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSelectionCard({
    required IconData icon,
    Color? iconColor,
    required String title,
    required String subtitle,
    String? note,
    IconData? noteIcon,
    required Widget child,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final effectiveIconColor = iconColor ?? colorScheme.primary;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: effectiveIconColor, size: 18),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: colorScheme.onSurface,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 13,
              color: colorScheme.onSurface.withValues(alpha: 0.85),
            ),
          ),
          const SizedBox(height: 12),
          child,
          if (note != null) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Icon(
                  noteIcon,
                  size: 14,
                  color: colorScheme.onSurface.withValues(alpha: 0.85),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    note,
                    style: TextStyle(
                      fontSize: 13,
                      color: colorScheme.onSurface.withValues(alpha: 0.85),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildLogo(ThemeData theme) {
    return Column(
      children: [
        Image.asset(
          'assets/images/logo.png',
          height: 80,
          cacheHeight: (80 * MediaQuery.devicePixelRatioOf(context)).round(),
        ),
        const SizedBox(height: 6),
        Text(
          'CLARO',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: theme.colorScheme.primary,
            letterSpacing: 3,
          ),
        ),
      ],
    );
  }

  bool isBasicInfoValid() {
    return _nameController.text.trim().isNotEmpty &&
        _dateOfBirth != null &&
        _avatar != null;
  }

  bool _isFormValid() {
    // At least one health condition must be selected
    final hasCondition = _conditions.values.any((selected) => selected);
    return hasCondition;
  }

  Widget _buildButton(
    String label,
    VoidCallback onTap,
    ThemeData theme, {
    bool checkValidation = false,
    bool Function()? isFormValid,
  }) {
    final colorScheme = theme.colorScheme;
    final enabledChecker = isFormValid ?? _isFormValid;
    final isButtonEnabled = checkValidation
        ? (enabledChecker() && !_isLoading)
        : !_isLoading;
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: isButtonEnabled
              ? colorScheme.primary
              : colorScheme.outlineVariant,
          foregroundColor: isButtonEnabled
              ? colorScheme.onPrimary
              : colorScheme.onSurfaceVariant,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        onPressed: isButtonEnabled ? onTap : null,
        child: _isLoading
            ? SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(
                  color: colorScheme.onPrimary,
                  strokeWidth: 2,
                ),
              )
            : Text(
                label,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
      ),
    );
  }
}
