import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';
import 'generated/l10n/app_localizations.dart';
import 'services/theme_service.dart';
import 'services/locale_service.dart';
import 'services/get_started_service.dart';
import 'services/auth_service.dart';
import 'services/guest_session.dart';
import 'services/haptic_service.dart';
import 'services/text_size_service.dart';
import 'services/voice_assistant_service.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/onboarding_screen.dart';
import 'screens/otp_verification_screen.dart';
import 'screens/select_language_screen.dart';
import 'screens/get_started_screen.dart';
import 'screens/splash_screen.dart';
import 'dart:async';
import 'data/services/backend_locator.dart';
import 'data/repositories/product_repository.dart';

void main() async {
  final totalStartupStopwatch = Stopwatch()..start();
  WidgetsFlutterBinding.ensureInitialized();

  await _initializeApp();
  runApp(const ClaroApp());
  totalStartupStopwatch.stop();
  debugPrint('TIMING [Startup]: Total startup initialization took ${totalStartupStopwatch.elapsedMilliseconds}ms');

  WidgetsBinding.instance.addPostFrameCallback((_) {
    final firstFrameStopwatch = Stopwatch()..start();
    unawaited(() async {
      try {
        await VoiceAssistantService.initialize();
        firstFrameStopwatch.stop();
        debugPrint('TIMING [Startup]: Deferred background services (VoiceAssistant, TTS) initialized in ${firstFrameStopwatch.elapsedMilliseconds}ms');

        final repo = BackendLocator.productRepository;
        if (repo is FirestoreProductRepository) {
          await repo.preloadOfflineCatalog();
        }

        unawaited(BackendLocator.pendingReportsService.flushPendingReports());
      } catch (e) {
        debugPrint('TIMING [Startup]: Deferred background service init warning: $e');
      }
    }());
  });
}

Future<void> _initializeApp() async {
  // 1. Concurrently load .env, Firebase, SharedPreferences, and PackageInfo
  final preInitStopwatch = Stopwatch()..start();
  final results = await Future.wait([
    dotenv.load(fileName: '.env'),
    Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    ),
    SharedPreferences.getInstance(),
    PackageInfo.fromPlatform(),
  ]);
  preInitStopwatch.stop();
  debugPrint('TIMING [Startup]: Core parallel I/O (dotenv, Firebase, SharedPreferences, PackageInfo) took ${preInitStopwatch.elapsedMilliseconds}ms');

  // Enable Firestore offline persistence for automatic sync of favorites & writes
  FirebaseFirestore.instance.settings = const Settings(
    persistenceEnabled: true,
    cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
  );

  final prefs = results[2] as SharedPreferences;
  final packageInfo = results[3] as PackageInfo;
  final currentVersion = '${packageInfo.version}+${packageInfo.buildNumber}';
  final lastRunVersion = prefs.getString('last_run_version');

  // Only force a sign-out when this launch follows an app UPDATE
  if (lastRunVersion != null && lastRunVersion != currentVersion) {
    await AuthService().signOut();
  }
  await prefs.setString('last_run_version', currentVersion);

  // 2. Synchronous/Fast In-memory preferences initialization
  final prefsInitStopwatch = Stopwatch()..start();
  await Future.wait([
    initializeThemeMode(),
    LocaleService.initializeLocale(),
    GetStartedService.initialize(),
    HapticService().init(),
    TextSizeService.initialize(),
  ]);
  prefsInitStopwatch.stop();
  debugPrint('TIMING [Startup]: Preferences initialization took ${prefsInitStopwatch.elapsedMilliseconds}ms');

}

class ClaroApp extends StatelessWidget {
  const ClaroApp({super.key});

  static const _primaryRed = Color(0xFF8B1A1A);

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeModeNotifier,
      builder: (context, themeMode, _) {
        return ValueListenableBuilder<Locale>(
          valueListenable: LocaleService.localeNotifier,
          builder: (context, locale, _) {
            return ValueListenableBuilder<double>(
              valueListenable: TextSizeService.textSizeNotifier,
              builder: (context, textSize, _) {
                return MaterialApp(
                  title: 'CLARO',
                  debugShowCheckedModeBanner: false,
                  locale: locale,
                  localizationsDelegates: AppLocalizations.localizationsDelegates,
                  supportedLocales: AppLocalizations.supportedLocales,
                  themeMode: themeMode,
                  theme: _buildTheme(Brightness.light),
                  darkTheme: _buildTheme(Brightness.dark),
                  navigatorObservers: [VoiceAssistantService.navigatorObserver],
                  builder: (context, child) {
                    final mediaQuery = MediaQuery.of(context);
                    // Combine user text size preference with system font scaling,
                    // clamping to 0.85 - 1.30 so text enlarges clearly while keeping
                    // all UI cards, headers, buttons, and layouts consistent across screens.
                    final effectiveScale = (textSize * mediaQuery.textScaler.scale(1.0)).clamp(0.85, 1.30);
                    return _VoiceInteractionStopper(
                      child: MediaQuery(
                        data: mediaQuery.copyWith(
                          textScaler: TextScaler.linear(effectiveScale),
                        ),
                        child: child!,
                      ),
                    );
                  },
                  home: const RootGate(),
                );
              },
            );
          },
        );
      },
    );
  }

  ThemeData _buildTheme(Brightness brightness) {
    final isLight = brightness == Brightness.light;
    final primaryColor = isLight ? _primaryRed : Colors.red;
    return ThemeData(
      brightness: brightness,
      primaryColor: primaryColor,
      scaffoldBackgroundColor: isLight ? const Color(0xFFF5F0EE) : const Color(0xFF121212),
      colorScheme: ColorScheme(
        brightness: brightness,
        primary: primaryColor,
        onPrimary: Colors.white,
        secondary: isLight ? const Color(0xFFD32F2F) : const Color(0xFFEF5350),
        onSecondary: Colors.white,
        surface: isLight ? Colors.white : const Color(0xFF1E1E1E),
        onSurface: isLight ? const Color(0xFF1A1A1A) : const Color(0xFFE0E0E0),
        error: Colors.redAccent,
        onError: Colors.white,
        surfaceContainerHighest: isLight ? const Color(0xFFE0E0E0) : const Color(0xFF2C2C2C),
        outlineVariant: isLight ? const Color(0xFFBDBDBD) : const Color(0xFF424242),
        onSurfaceVariant: isLight ? const Color(0xFF757575) : const Color(0xFF9E9E9E),
      ),
      useMaterial3: true,
    );
  }
}

class _VoiceInteractionStopper extends StatefulWidget {
  final Widget child;

  const _VoiceInteractionStopper({required this.child});

  @override
  State<_VoiceInteractionStopper> createState() => _VoiceInteractionStopperState();
}

class _VoiceInteractionStopperState extends State<_VoiceInteractionStopper> {
  static const _movementThreshold = 8.0;
  Offset? _pointerDownPosition;
  bool _pointerMoved = false;

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (event) {
        _pointerDownPosition = event.position;
        _pointerMoved = false;
      },
      onPointerMove: (event) {
        final start = _pointerDownPosition;
        if (start != null && (event.position - start).distance > _movementThreshold) {
          _pointerMoved = true;
        }
      },
      onPointerUp: (_) {
        if (!_pointerMoved) {
          VoiceAssistantService.instance.stopAudio();
        }
        _pointerDownPosition = null;
      },
      child: widget.child,
    );
  }
}

/// App entry point. Routes, in order:
/// 0. SplashScreen (animated logo launch)
/// 1. Get Started not yet seen → GetStartedScreen
/// 2. Language not yet explicitly selected → SelectLanguageScreen
/// 3. Otherwise → AuthGate (Login/Sign Up → onboarding → Home, as below)
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  bool _showSplash = true;

  void _onSplashComplete() {
    if (mounted) {
      setState(() {
        _showSplash = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 400),
      child: _showSplash
          ? SplashScreen(
              key: const ValueKey('splash'),
              onInitializationComplete: _onSplashComplete,
            )
          : ValueListenableBuilder<bool>(
              key: const ValueKey('root_flow'),
              valueListenable: GetStartedService.hasSeenGetStartedNotifier,
              builder: (context, hasSeenGetStarted, _) {
                if (!hasSeenGetStarted) {
                  return const GetStartedScreen();
                }
                return ValueListenableBuilder<bool>(
                  valueListenable: LocaleService.hasSelectedLanguageNotifier,
                  builder: (context, hasSelectedLanguage, _) {
                    if (!hasSelectedLanguage) {
                      return const SelectLanguageScreen();
                    }
                    return const AuthGate();
                  },
                );
              },
            ),
    );
  }
}

/// Routes users based on authentication state. Guest mode is process-local and
/// is checked before Firebase profile lookup so it never enters onboarding.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: GuestSession.isGuest,
      builder: (context, isGuest, _) {
        if (isGuest) return const HomeScreen();
        return StreamBuilder<User?>(
          stream: FirebaseAuth.instance.authStateChanges(),
          builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final user = snapshot.data;

        return ValueListenableBuilder<bool>(
          valueListenable: AuthService.isAuthenticating,
          builder: (context, isAuthenticating, _) {
            if (user == null) {
              return const LoginScreen();
            }

            if (isAuthenticating) {
              return ValueListenableBuilder<Map<String, dynamic>?>(
                valueListenable: AuthService.pendingMfaChallenge,
                builder: (context, challenge, _) {
                  if (challenge != null) {
                    return OtpVerificationScreen(
                      email: challenge['email'],
                      password: challenge['password'],
                      uid: challenge['uid'].toString(),
                      otpCode: challenge['code']?.toString(),
                      emailSent: challenge['emailSent'] == true,
                      expiresAt: challenge['expiresAt'] as DateTime?,
                    );
                  }
                  return const Scaffold(
                    body: Center(child: CircularProgressIndicator()),
                  );
                },
              );
            }

            // Verify session validity and MFA completion
            return FutureBuilder<bool>(
              future: AuthService().isSessionValid(user.uid),
              builder: (context, sessionSnap) {
                if (sessionSnap.connectionState == ConnectionState.waiting) {
                  return const Scaffold(
                    body: Center(child: CircularProgressIndicator()),
                  );
                }

                if (sessionSnap.hasError || sessionSnap.data == false) {
                  AuthService().signOut();
                  return const LoginScreen();
                }

                return FutureBuilder(
                  future: AuthService().db.collection('users').doc(user.uid).get(),
                  builder: (context, AsyncSnapshot docSnap) {
                    if (docSnap.connectionState == ConnectionState.waiting) {
                      return const Scaffold(
                        body: Center(child: CircularProgressIndicator()),
                      );
                    }

                    if (docSnap.hasError) {
                      AuthService().signOut();
                      return const LoginScreen();
                    }

                    if (docSnap.hasData && docSnap.data.exists) {
                      final data = docSnap.data.data() as Map<String, dynamic>?;

                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        final hapticPref = data?['vibrationFeedback'] ?? false;
                        HapticService().updateEnabled(hapticPref);

                        final textSizePref = (data?['textSize'] as num?)?.toDouble() ?? 1.0;
                        if (TextSizeService.textSizeNotifier.value != textSizePref) {
                          TextSizeService.textSizeNotifier.value = textSizePref;
                        }

                        final voicePref = data?['voiceAssistant'] ?? false;
                        if (VoiceAssistantService.isEnabledNotifier.value != voicePref) {
                          VoiceAssistantService.isEnabledNotifier.value = voicePref;
                        }

                        unawaited(BackendLocator.userRepository
                            .getHealthProfile(user.uid)
                            .then((_) {}, onError: (_) {}));
                      });

                      final bool onboarded = data?['onboardingComplete'] ?? false;
                      if (onboarded) {
                        return const HomeScreen();
                      }
                    }

                    return const OnboardingScreen();
                  },
                );
              },
            );
          },
        );
          },
        );
      },
    );
  }
}